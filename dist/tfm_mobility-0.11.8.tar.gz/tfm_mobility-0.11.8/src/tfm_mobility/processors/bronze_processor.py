import os
import logging
from typing import List
from delta.tables import DeltaTable
from pyspark.sql import SparkSession, DataFrame

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

class BronzeProcessor:
    """Procesador para la capa Bronze gestionando Delta MERGE condicional sin falsas actualizaciones."""

    def __init__(self, spark: SparkSession):
        self.spark = spark
        self.spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", "true")

    def _clean_spark_path(self, path: str) -> str:
        if not path:
            return ""
        clean = os.path.normpath(path).replace("\\", "/")
        for prefix in ["/lakehouse/default/", "lakehouse/default/", "/Files/"]:
            if clean.startswith(prefix):
                clean = clean[len(prefix):]
        if not clean.startswith("Files/"):
            clean = f"Files/{clean.lstrip('/')}"
        return clean

    def merge_into_bronze(self, raw_df: DataFrame, table_name: str, primary_keys: List[str]) -> None:
        if raw_df is None or raw_df.rdd.isEmpty():
            logging.warning(f"⚠️ El DataFrame de origen para {table_name} está vacío. Cancelando MERGE.")
            return

        if "ingestion_timestamp" in raw_df.columns:
            dedup_raw_df = raw_df.orderBy(raw_df["ingestion_timestamp"].desc()).dropDuplicates(subset=primary_keys)
        else:
            dedup_raw_df = raw_df.dropDuplicates(subset=primary_keys)

        if self.spark.catalog.tableExists(table_name):
            delta_table = DeltaTable.forName(self.spark, table_name)
            merge_condition = " AND ".join([f"target.{col} = source.{col}" for col in primary_keys])

            meta_cols = {"landing_source_file", "ingestion_timestamp", "updated_source_file", "updated_timestamp"}
            data_cols = [c for c in dedup_raw_df.columns if c not in primary_keys and c not in meta_cols]

            if data_cols:
                update_condition = " OR ".join([f"NOT (target.{c} <=> source.{c})" for c in data_cols])
            else:
                update_condition = "1 = 0"

            insert_values = {col: f"source.{col}" for col in dedup_raw_df.columns if col not in ["updated_source_file", "updated_timestamp"]}
            insert_values["updated_source_file"] = "CAST(NULL AS STRING)"
            insert_values["updated_timestamp"] = "CAST(NULL AS TIMESTAMP)"

            update_values = {col: f"source.{col}" for col in dedup_raw_df.columns if col not in ["landing_source_file", "ingestion_timestamp"]}
            update_values["landing_source_file"] = "target.landing_source_file"
            update_values["ingestion_timestamp"] = "target.ingestion_timestamp"
            update_values["updated_source_file"] = "source.landing_source_file"
            update_values["updated_timestamp"] = "current_timestamp()"

            delta_table.alias("target") \
                .merge(dedup_raw_df.alias("source"), merge_condition) \
                .whenMatchedUpdate(condition=update_condition, set=update_values) \
                .whenNotMatchedInsert(values=insert_values) \
                .execute()
                
            logging.info(f"✅ MERGE condicional completado en '{table_name}'.")
        else:
            initial_df = dedup_raw_df.selectExpr(
                "*",
                "CAST(NULL AS STRING) AS updated_source_file",
                "CAST(NULL AS TIMESTAMP) AS updated_timestamp"
            )
            
            initial_df.write \
                .format("delta") \
                .mode("overwrite") \
                .option("overwriteSchema", "true") \
                .saveAsTable(table_name)
            logging.info(f"✨ Tabla Delta '{table_name}' creada por primera vez.")

    def promote_realtime_to_bronze(self) -> None:
        sources = [
            ("Files/raw/realtime/dgt_traffic", "bronze_dgt_traffic", ["record_id"]),
            ("Files/raw/realtime/nasa_nrt", "bronze_nasa_nrt", ["latitude", "longitude", "acq_date", "acq_time"]),
            ("Files/raw/realtime/weather", "bronze_weather", ["latitude", "longitude", "time"])
        ]

        for raw_path, table_name, pk in sources:
            clean_path = self._clean_spark_path(raw_path)
            try:
                raw_df = self.spark.read.parquet(clean_path)
                self.merge_into_bronze(raw_df, table_name, pk)
            except Exception as e:
                logging.error(f"❌ Error al procesar {table_name} desde {clean_path}: {e}")

    def promote_batch_to_bronze(self) -> None:
        sources = [
            ("Files/raw/batch/nasa_historical", "bronze_nasa_historical", ["latitude", "longitude", "acq_date", "acq_time"]),
            ("Files/raw/batch/osm_roads", "bronze_osm_roads", ["id"])
        ]

        for raw_path, table_name, pk in sources:
            clean_path = self._clean_spark_path(raw_path)
            try:
                raw_df = self.spark.read.parquet(clean_path)
                self.merge_into_bronze(raw_df, table_name, pk)
            except Exception as e:
                logging.error(f"❌ Error al procesar {table_name} desde {clean_path}: {e}")