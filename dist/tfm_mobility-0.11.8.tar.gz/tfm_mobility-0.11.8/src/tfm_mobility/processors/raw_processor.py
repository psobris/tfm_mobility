import os
import logging
import xml.etree.ElementTree as ET
from typing import Optional
from datetime import datetime, timezone
from pyspark.sql import SparkSession
from pyspark.sql import functions as F

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

class RawProcessor:
    """Procesador para la capa RAW promocionando de Landing a Parquet de forma incremental."""

    def __init__(self, spark: SparkSession):
        self.spark = spark

    def _clean_spark_path(self, path: str) -> str:
        if not path:
            return ""
        clean = os.path.normpath(path).replace("\\", "/")
        for prefix in ["/lakehouse/default/", "lakehouse/default/", "/Files/"]:
            if clean.startswith(prefix):
                clean = clean[len(prefix):]
        if not clean.startswith("Files/"):
            clean = f"Files/{clean.lstrip('/')}"
        return clean

    def _clean_local_path(self, path: str) -> str:
        if not path:
            return ""
        clean = os.path.normpath(path).replace("\\", "/")
        if not clean.startswith("/lakehouse/default/"):
            if clean.startswith("Files/"):
                return f"/lakehouse/default/{clean}"
            return f"/lakehouse/default/Files/{clean.lstrip('/')}"
        return clean

    def _get_current_hour_pattern(self, landing_base_path: str, extension: str) -> str:
        spark_base = self._clean_spark_path(landing_base_path)
        if spark_base.endswith(f".{extension}"):
            return spark_base
        now = datetime.now(timezone.utc)
        return f"{spark_base.rstrip('/')}/{now.strftime('%Y')}/{now.strftime('%m')}/{now.strftime('%d')}/{now.strftime('%H')}/*.{extension}"

    def landing_to_raw_csv(self, landing_path: str, raw_path: Optional[str] = None, is_batch: bool = False) -> None:
        spark_raw = self._clean_spark_path(raw_path or "Files/raw/realtime/nasa_nrt")
        input_pattern = self._get_current_hour_pattern(landing_path, "csv")
        
        logging.info(f"📄 Leyendo CSV Landing: {input_pattern}")
        try:
            df = self.spark.read.option("header", "true").option("inferSchema", "true").csv(input_pattern)
            if df.count() > 0:
                df = df.withColumn("landing_source_file", F.element_at(F.split(F.col("_metadata.file_name"), "/"), -1)) \
                       .withColumn("ingestion_timestamp", F.current_timestamp())
                df.write.format("parquet").mode("append").save(spark_raw)
                logging.info(f"✅ Anexado CSV a RAW Parquet en: {spark_raw}")
            else:
                logging.warning(f"⚠️ Sin datos CSV en: {input_pattern}")
        except Exception as e:
            logging.error(f"❌ Error procesando CSV Landing ({landing_path}): {e}")

    def landing_to_raw_json(self, landing_path: str, raw_path: Optional[str] = None, is_batch: bool = False) -> None:
        spark_raw = self._clean_spark_path(raw_path or "Files/raw/realtime/weather")
        input_pattern = self._get_current_hour_pattern(landing_path, "json")
        
        logging.info(f"📄 Leyendo JSON Landing: {input_pattern}")
        try:
            df = self.spark.read.option("multiline", "true").json(input_pattern)
            if df.count() > 0:
                df = df.withColumn("landing_source_file", F.element_at(F.split(F.col("_metadata.file_name"), "/"), -1)) \
                       .withColumn("ingestion_timestamp", F.current_timestamp())
                df.write.format("parquet").mode("append").save(spark_raw)
                logging.info(f"✅ Anexado JSON a RAW Parquet en: {spark_raw}")
            else:
                logging.warning(f"⚠️ Sin datos JSON en: {input_pattern}")
        except Exception as e:
            logging.error(f"❌ Error procesando JSON Landing ({landing_path}): {e}")

    def landing_to_raw_dgt_xml(self, landing_path: str, raw_path: Optional[str] = None) -> None:
        spark_raw = self._clean_spark_path(raw_path or "Files/raw/realtime/dgt_traffic")
        now = datetime.now(timezone.utc)
        local_base = self._clean_local_path(landing_path)
        hour_folder = os.path.join(local_base, now.strftime('%Y'), now.strftime('%m'), now.strftime('%d'), now.strftime('%H'))
        
        target_dir = hour_folder if os.path.exists(hour_folder) else local_base
        xml_files = []
        
        if os.path.isfile(target_dir):
            xml_files.append(target_dir)
        elif os.path.exists(target_dir):
            for root, _, files in os.walk(target_dir):
                for f in files:
                    if f.endswith(".xml"):
                        xml_files.append(os.path.join(root, f))

        if not xml_files:
            logging.warning(f"⚠️ No se encontraron XMLs de DGT en: {target_dir}")
            return

        records = []
        for xml_file in xml_files:
            file_name = os.path.basename(xml_file)
            try:
                tree = ET.parse(xml_file)
                root = tree.getroot()
                for elem in root.iter():
                    if elem.attrib or elem.text:
                        row = {child.tag: child.text.strip() for child in elem if child.text}
                        if row:
                            row["landing_source_file"] = file_name
                            records.append(row)
            except Exception as e:
                logging.error(f"⚠️ Error parseando XML {xml_file}: {e}")

        if records:
            df = self.spark.createDataFrame(records) \
                     .withColumn("ingestion_timestamp", F.current_timestamp())
            df.write.format("parquet").mode("append").save(spark_raw)
            logging.info(f"✅ XML DGT ({len(records)} registros) anexado a Parquet RAW en: {spark_raw}")

    def landing_to_raw_osm(self, landing_path: str, raw_path: Optional[str] = None) -> None:
        target_raw = raw_path or "Files/raw/batch/osm_roads"
        self.landing_to_raw_json(landing_path, target_raw, is_batch=True)