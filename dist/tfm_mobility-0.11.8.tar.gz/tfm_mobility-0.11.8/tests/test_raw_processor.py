import pytest
from unittest.mock import MagicMock, patch
from tfm_mobility.processors.raw_processor import RawProcessor

@pytest.fixture
def mock_spark():
    spark = MagicMock()
    return spark

def test_raw_processor_landing_to_raw_csv(mock_spark):
    """Verifica la inyección de 'landing_source_file' e 'ingestion_timestamp' en la conversión CSV -> Parquet."""
    processor = RawProcessor(spark=mock_spark)
    
    mock_df = MagicMock()
    mock_df.count.return_value = 5
    mock_df.withColumn.return_value = mock_df
    
    mock_reader = MagicMock()
    mock_reader.option.return_value = mock_reader
    mock_reader.csv.return_value = mock_df
    mock_spark.read = mock_reader

    # Mockear las funciones F.element_at, F.split y F.col para evitar errores de contexto JVM
    with patch("tfm_mobility.processors.raw_processor.F") as mock_f:
        mock_f.element_at.return_value = MagicMock()
        mock_f.split.return_value = MagicMock()
        mock_f.col.return_value = MagicMock()
        mock_f.current_timestamp.return_value = MagicMock()

        processor.landing_to_raw_csv("Files/landing/realtime/nasa_nrt", "Files/raw/realtime/nasa_nrt")

        # Confirmar que se llamaron a las inyecciones de metadatos y a la escritura Parquet
        assert mock_df.withColumn.call_count == 2
        mock_df.write.format.assert_called_once_with("parquet")

def test_raw_processor_landing_to_raw_json(mock_spark):
    """Verifica la inyección de metadatos de trazabilidad en la conversión JSON -> Parquet."""
    processor = RawProcessor(spark=mock_spark)
    
    mock_df = MagicMock()
    mock_df.count.return_value = 3
    mock_df.withColumn.return_value = mock_df
    
    mock_reader = MagicMock()
    mock_reader.option.return_value = mock_reader
    mock_reader.json.return_value = mock_df
    mock_spark.read = mock_reader

    with patch("tfm_mobility.processors.raw_processor.F") as mock_f:
        mock_f.element_at.return_value = MagicMock()
        mock_f.split.return_value = MagicMock()
        mock_f.col.return_value = MagicMock()
        mock_f.current_timestamp.return_value = MagicMock()

        processor.landing_to_raw_json("Files/landing/realtime/weather", "Files/raw/realtime/weather")

        assert mock_df.withColumn.call_count == 2
        mock_df.write.format.assert_called_once_with("parquet")