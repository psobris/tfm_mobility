import logging
import os
from datetime import datetime
import requests
import pandas as pd
import numpy as np
from typing import Optional, List, Dict, Any

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

def generate_spain_grid(step: float = 0.5) -> List[Dict[str, float]]:
    """Genera un grid uniforme de coordenadas (Lat/Lon) que cubre el 100% de España."""
    # Bounding Box de España (Península y Baleares)
    lat_min, lat_max = 35.8, 43.8
    lon_min, lon_max = -9.3, 3.3
    
    lats = np.arange(lat_min, lat_max + step, step)
    lons = np.arange(lon_min, lon_max + step, step)
    
    grid = []
    for lat in lats:
        for lon in lons:
            grid.append({
                "lat": round(float(lat), 4),
                "lon": round(float(lon), 4)
            })
    return grid

class WeatherIngestor:
    """Ingestor meteorológico con cobertura espacial continua (100% del mapa)."""

    BASE_URL = "https://api.open-meteo.com/v1/forecast"

    def __init__(self, step_degrees: float = 0.5):
        # Genera el 100% de los puntos de la cuadrícula geográfica
        self.grid = generate_spain_grid(step=step_degrees)

    def fetch_forecast(self, forecast_days: int = 7) -> Optional[pd.DataFrame]:
        """Obtiene la predicción hora a hora para cada punto de la cuadrícula nacional."""
        # Open-Meteo acepta listas de coordenadas separadas por coma en una sola llamada
        lats = ",".join([str(p["lat"]) for p in self.grid])
        lons = ",".join([str(p["lon"]) for p in self.grid])
        
        params = {
            "latitude": lats,
            "longitude": lons,
            "hourly": "temperature_2m,relative_humidity_2m,precipitation_probability,precipitation,rain,showers,snowfall,wind_speed_10m,wind_gusts_10m",
            "forecast_days": forecast_days,
            "timezone": "Europe/Madrid"
        }
        
        try:
            logging.info(f"🌤️ [WEATHER] Solicitando cobertura espacial total ({len(self.grid)} puntos de grid)...")
            response = requests.get(self.BASE_URL, params=params, timeout=30)
            response.raise_for_status()
            
            data = response.json()
            
            # Si se envían múltiples coordenadas, Open-Meteo devuelve una lista de respuestas
            results = data if isinstance(data, list) else [data]
            
            all_dfs = []
            for item in results:
                hourly = item.get("hourly", {})
                if hourly:
                    df_item = pd.DataFrame(hourly)
                    df_item["latitude"] = item.get("latitude")
                    df_item["longitude"] = item.get("longitude")
                    df_item["elevation"] = item.get("elevation", 0)
                    all_dfs.append(df_item)
                    
            if not all_dfs:
                return None
                
            combined_df = pd.concat(all_dfs, ignore_index=True)
            logging.info(f"✅ [WEATHER OK] Obtenidos {len(combined_df)} registros cubrirán el 100% del mapa.")
            return combined_df

        except Exception as e:
            logging.error(f"❌ [WEATHER ERROR] Error en descarga masiva por grid: {e}")
            return None

    def fetch_stream_to_landing(self, landing_dir: str = "/lakehouse/default/Files/landing/realtime/weather") -> Optional[str]:
        """Guarda la extracción de la malla completa en Landing."""
        df = self.fetch_forecast()
        if df is None or df.empty:
            return None
            
        os.makedirs(landing_dir, exist_ok=True)
        timestamp_str = datetime.now().strftime("%Y%m%d_%H%M%S")
        file_path = os.path.join(landing_dir, f"weather_{timestamp_str}.json")
        
        df.to_json(file_path, orient="records", date_format="iso")
        logging.info(f"💾 [WEATHER LANDING] Grid espacial guardado en: {file_path}")
        return file_path