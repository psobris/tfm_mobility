from unittest.mock import MagicMock, patch
from tfm_mobility.processors.bronze_processor import BronzeProcessor

@patch("tfm_mobility.processors.bronze_processor.F.current_timestamp")
def test_bronze_processor_append_metadata(mock_ts):
    """Verifica que se añade la columna ingestion_timestamp al DataFrame."""
    mock_spark = MagicMock()
    processor = BronzeProcessor(mock_spark)
    
    mock_df = MagicMock()
    processor._append_ingestion_metadata(mock_df)
    
    assert mock_df.withColumn.called

def test_promote_realtime_to_bronze():
    """Prueba la promoción en lote para fuentes NRT."""
    mock_spark = MagicMock()
    mock_df = MagicMock()
    mock_writer = MagicMock()
    
    mock_spark.read.parquet.return_value = mock_df
    mock_df.withColumn.return_value = mock_df
    mock_df.count.return_value = 100
    
    mock_df.write.format.return_value = mock_writer
    mock_writer.mode.return_value = mock_writer
    mock_writer.option.return_value = mock_writer

    processor = BronzeProcessor(mock_spark)
    processor.promote_realtime_to_bronze()

    assert mock_spark.read.parquet.called

def test_promote_batch_to_bronze():
    """Prueba la promoción en lote para fuentes Batch."""
    mock_spark = MagicMock()
    mock_df = MagicMock()
    mock_writer = MagicMock()
    
    mock_spark.read.parquet.return_value = mock_df
    mock_df.withColumn.return_value = mock_df
    mock_df.count.return_value = mock_df
    
    mock_df.write.format.return_value = mock_writer
    mock_writer.mode.return_value = mock_writer
    mock_writer.option.return_value = mock_writer

    processor = BronzeProcessor(mock_spark)
    processor.promote_batch_to_bronze()

    assert mock_spark.read.parquet.called