import os
import logging
import json
import requests
from datetime import datetime
from tfm_mobility.utils.api_client import APIClient

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

class OSMIngester:
    """Ingester para datos de infraestructura de emergencia de OpenStreetMap (Overpass API)."""

    def __init__(self, base_landing_path: str = "/lakehouse/default/Files/landing/osm"):
        self.client = APIClient()
        self.base_landing_path = base_landing_path
        self.osm_url = "https://overpass-api.de/api/interpreter"

    def fetch_hospitals_to_landing(self) -> str:
        logging.info("📡 Solicitando puntos de refugio/hospitales a OpenStreetMap...")
        query = """
        [out:json];
        node["amenity"="hospital"](36.0,-9.5,43.8,3.3);
        out body;
        """
        
        try:
            response = requests.post(self.osm_url, data={"data": query}, timeout=30)
            if response.status_code == 200:
                raw_json = response.json()
                
                # 📅 Estructura de directorios: YYYY/MM/DD
                now = datetime.now()
                year_str = now.strftime("%Y")
                month_str = now.strftime("%m")
                day_str = now.strftime("%d")

                dir_dest = os.path.join(self.base_landing_path, year_str, month_str, day_str)
                os.makedirs(dir_dest, exist_ok=True)

                # ⏱️ Nombre de archivo con timestamp: osm_hospitals_YYYYMMDD_HHMMSS.json
                timestamp_str = now.strftime("%Y%m%d_%H%M%S")
                file_name = f"osm_hospitals_{timestamp_str}.json"
                file_path = os.path.join(dir_dest, file_name)

                with open(file_path, "w", encoding="utf-8") as f:
                    json.dump(raw_json, f, indent=2)

                logging.info(f"📥 [LANDING OK] Hospitales OSM guardados en: {file_path}")
                return file_path
        except Exception as e:
            logging.error(f"❌ Error al consultar OSM Overpass API: {e}")
            
        return None