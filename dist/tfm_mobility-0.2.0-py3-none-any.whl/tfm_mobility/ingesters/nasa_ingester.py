import os
import logging
from datetime import datetime
from tfm_mobility.utils.api_client import APIClient

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

class NASAIngester:
    """Clase para gestionar la ingesta de datos de la NASA FIRMS a Landing y Raw."""

    def __init__(self, base_landing_path: str = "/lakehouse/default/Files/landing/nasa_firms"):
        self.client = APIClient()
        self.base_landing_path = base_landing_path
        self.nasa_url = "https://firms.modaps.eosdis.nasa.gov/data/active_fire/suomi-npp-viirs-c2/csv/SUOMI_VIIRS_C2_Europe_24h.csv"

    def fetch_to_landing(self) -> str:
        logging.info("📡 Iniciando descarga desde NASA FIRMS hacia LANDING...")
        raw_data = self.client.get_text(self.nasa_url)

        if not raw_data or "latitude" not in raw_data:
            logging.error("❌ Fallo en la recepción de datos válidos de la NASA.")
            return None

        # 📅 Estructura de directorios: YYYY/MM/DD
        now = datetime.now()
        year_str = now.strftime("%Y")
        month_str = now.strftime("%m")
        day_str = now.strftime("%d")
        
        dir_dest = os.path.join(self.base_landing_path, year_str, month_str, day_str)
        os.makedirs(dir_dest, exist_ok=True)

        # ⏱️ Nombre de archivo con timestamp: nasa_viirs_YYYYMMDD_HHMMSS.csv
        timestamp_str = now.strftime("%Y%m%d_%H%M%S")
        file_name = f"nasa_viirs_{timestamp_str}.csv"
        file_path = os.path.join(dir_dest, file_name)

        with open(file_path, "w", encoding="utf-8") as f:
            f.write(raw_data)

        logging.info(f"📥 [LANDING OK] Archivo guardado en: {file_path}")
        return file_path