import requests
import logging
from typing import Dict, Any, Optional

# Configuración básica de logs para ver en pantalla qué peticiones hace el cliente
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

class APIClient:
    """
    Clase cliente modular para realizar peticiones HTTP a APIs REST o archivos públicos de forma segura.
    Incluye manejo de cabeceras, tiempos de espera (timeouts) y captura de errores de red.
    """
    def __init__(self, base_url: str = "", default_headers: Optional[Dict[str, str]] = None):
        """
        Inicializa el cliente con una URL base opcional y cabeceras por defecto.
        """
        self.base_url = base_url
        self.headers = default_headers or {
            'User-Agent': 'TFM_DataEngineering_UCM/1.0 (contacto: paula.sobrados@ucm.es)'
        }

    def get(self, endpoint: str = "", params: Optional[Dict[str, Any]] = None, timeout: int = 15) -> Optional[requests.Response]:
        """
        Realiza una petición HTTP GET.
        
        :param endpoint: Ruta o endpoint que añadir a la URL base.
        :param params: Diccionario de parámetros para la query (ej. ?q=Madrid).
        :param timeout: Tiempo máximo de espera en segundos.
        :return: Objeto Response de la librería requests o None si hubo un error.
        """
        url = f"{self.base_url}{endpoint}" if self.base_url else endpoint
        logging.info(f"Iniciando petición GET a: {url}")

        try:
            response = requests.get(url, headers=self.headers, params=params, timeout=timeout)
            response.raise_for_status()  # Lanza una excepción si el código es 4xx o 5xx
            logging.info(f"Petición exitosa [{response.status_code}] desde: {url}")
            return response

        except requests.exceptions.HTTPError as http_err:
            logging.error(f"Error HTTP [{response.status_code}] en {url}: {http_err}")
        except requests.exceptions.Timeout:
            logging.error(f"Tiempo de espera agotado ({timeout}s) al conectar con {url}")
        except requests.exceptions.RequestException as req_err:
            logging.error(f"Fallo de conexión en {url}: {req_err}")
        
        return None

    def get_json(self, endpoint: str = "", params: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
        """
        Realiza una petición GET y devuelve la respuesta parseada como un diccionario JSON.
        """
        response = self.get(endpoint=endpoint, params=params)
        if response:
            try:
                return response.json()
            except Exception as e:
                logging.error(f"Error al decodificar la respuesta JSON: {e}")
        return None

    def get_text(self, endpoint: str = "", params: Optional[Dict[str, Any]] = None) -> Optional[str]:
        """
        Realiza una petición GET y devuelve la respuesta como texto plano (útil para CSVs como NASA FIRMS).
        """
        response = self.get(endpoint=endpoint, params=params)
        if response:
            return response.text
        return None