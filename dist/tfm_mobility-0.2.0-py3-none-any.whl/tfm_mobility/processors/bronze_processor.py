import logging
from datetime import datetime

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

class BronzeProcessor:
    """Procesador PySpark para transformar datos de Landing a las tablas Delta de Bronze."""

    def __init__(self, spark_session):
        self.spark = spark_session

    def process_nasa_to_bronze(self, landing_csv_path: str, bronze_table_path: str):
        """Lee el CSV de la NASA en Landing y lo escribe en formato Delta en Bronze."""
        logging.info("⚙️ Procesando NASA Landing a Bronze Delta Table...")
        
        df_landing = self.spark.read.option("header", "true").option("inferSchema", "true").csv(landing_csv_path)
        
        from pyspark.sql.functions import current_timestamp, lit
        df_bronze = df_landing \
            .with_column("ingestion_timestamp", current_timestamp()) \
            .with_column("source_file", lit(landing_csv_path))

        df_bronze.write.format("delta").mode("append").save(bronze_table_path)
        logging.info(f"🥉 [BRONZE OK] Tabla Delta NASA actualizada en: {bronze_table_path}")
        return df_bronze