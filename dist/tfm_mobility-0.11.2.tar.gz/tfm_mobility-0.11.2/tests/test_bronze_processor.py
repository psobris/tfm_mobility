import pytest
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from tfm_mobility.processors.bronze_processor import BronzeProcessor

@pytest.fixture(scope="module")
def spark_session():
    """Crea una sesión de Spark estándar para tests unitarios."""
    spark = SparkSession.builder \
        .appName("TestBronzeProcessor") \
        .master("local[1]") \
        .getOrCreate()
    yield spark
    spark.stop()

def test_append_ingestion_metadata(spark_session):
    """Verifica que la función _append_ingestion_metadata añada la columna 'ingestion_timestamp'."""
    processor = BronzeProcessor(spark_session)
    
    df_sample = spark_session.createDataFrame(
        [(1, "evento_1"), (2, "evento_2")],
        ["id", "descripcion"]
    )
    
    df_with_meta = processor._append_ingestion_metadata(df_sample)
    
    # 1. Comprobar que la columna existe en el esquema
    assert "ingestion_timestamp" in df_with_meta.columns
    
    # 2. Comprobar el tipo de dato
    dtype_dict = dict(df_with_meta.dtypes)
    assert dtype_dict["ingestion_timestamp"] == "timestamp"

def test_bronze_deduplication(spark_session):
    """Prueba que la lógica de desduplicación por clave primaria funcione correctamente."""
    df_data = spark_session.createDataFrame(
        [
            ("40.4168", "-3.7038", "2026-08-12", 1000, 310.5),
            ("40.4168", "-3.7038", "2026-08-12", 1000, 310.5)
        ],
        ["latitude", "longitude", "acq_date", "acq_time", "bright_ti4"]
    )
    
    primary_keys = ["latitude", "longitude", "acq_date", "acq_time"]
    dedup_df = df_data.dropDuplicates(subset=primary_keys)
    
    # Verificar que el esquema generado mantiene las columnas clave
    assert len(dedup_df.columns) == 5
    assert set(primary_keys).issubset(set(dedup_df.columns))