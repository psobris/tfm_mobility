import json
from unittest.mock import patch, MagicMock
from tfm_mobility.ingesters.osm_ingester import OSMIngester

@patch("requests.post")
def test_osm_ingester_success(mock_post, tmp_path):
    fake_json = {"elements": [{"id": 123, "type": "way", "tags": {"highway": "motorway"}}]}
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = fake_json
    mock_post.return_value = mock_response

    # Comprobamos que acepta argumentos extra por kwargs sin fallar
    ingester = OSMIngester(base_landing_path=str(tmp_path))
    data = ingester.fetch_roads()

    assert data is not None
    assert "elements" in data
    assert len(data["elements"]) == 1

@patch("requests.post")
def test_osm_ingester_fetch_batch_and_stream_alias(mock_post, tmp_path):
    fake_json = {"elements": [{"id": 456, "type": "way"}]}
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = fake_json
    mock_post.return_value = mock_response

    ingester = OSMIngester()
    landing_dir = str(tmp_path / "landing" / "batch" / "osm_roads")
    
    # Probamos tanto el método stream como el alias batch que exige el notebook 01_osm
    path_stream = ingester.fetch_stream_to_landing(landing_dir=landing_dir)
    path_batch = ingester.fetch_batch_to_landing(landing_dir=landing_dir)

    assert path_stream is not None
    assert path_batch is not None
    assert "osm_roads_" in path_batch