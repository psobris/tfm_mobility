from unittest.mock import MagicMock, patch
from tfm_mobility.processors.silver_processor import SilverProcessor, LAT_MIN, LAT_MAX, LON_MIN, LON_MAX

def test_silver_processor_bbox_constants():
    """Valida los límites geográficos transfronterizos."""
    assert LAT_MIN == 27.5
    assert LAT_MAX == 45.0
    assert LON_MIN == -18.5
    assert LON_MAX == 7.5

def test_silver_processor_filter_regional_bbox():
    """Verifica la invocación del método de filtrado sobre el DataFrame."""
    mock_spark = MagicMock()
    processor = SilverProcessor(mock_spark)
    
    mock_df = MagicMock()
    
    # Parcheamos _filter_regional_bbox para simular la devolución del df filtrado
    with patch.object(processor, '_filter_regional_bbox', return_value=mock_df) as mock_filter:
        res = processor._filter_regional_bbox(mock_df)
        assert mock_filter.called
        assert res == mock_df

def test_silver_processor_process_all_calls():
    """Verifica que process_all() llame a los subprocesos correspondientes."""
    mock_spark = MagicMock()
    processor = SilverProcessor(mock_spark)

    with patch.object(processor, 'process_nasa_historical') as mock_hist, \
         patch.object(processor, 'process_nasa_nrt') as mock_nrt, \
         patch.object(processor, 'process_weather') as mock_weather, \
         patch.object(processor, 'process_dgt_traffic') as mock_dgt:
        
        processor.process_all()

        assert mock_hist.called
        assert mock_nrt.called
        assert mock_weather.called
        assert mock_dgt.called