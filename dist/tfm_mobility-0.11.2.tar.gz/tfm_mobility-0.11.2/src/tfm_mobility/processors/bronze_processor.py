import logging
from pyspark.sql import SparkSession
from pyspark.sql import functions as F

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

class BronzeProcessor:
    """Procesador para la capa Bronze que garantiza trazabilidad de ingesta (ingestion_timestamp) y desduplicación."""

    def __init__(self, spark: SparkSession):
        self.spark = spark

    def _append_ingestion_metadata(self, df):
        """Añade la marca temporal exacta de la ingesta en el Data Lake (convertida a hora local)."""
        return df.withColumn(
            "ingestion_timestamp", 
            F.from_utc_timestamp(F.current_timestamp(), "Europe/Madrid")
        )

    def _process_source_list(self, sources):
        for raw_path, table_name, primary_keys in sources:
            try:
                logging.info(f"⚙️ [BRONZE] Leyendo Parquet desde {raw_path}...")
                df = self.spark.read.parquet(raw_path)
                
                # OBLIGATORIO: Añadir siempre la marca temporal de ingesta
                df_with_meta = self._append_ingestion_metadata(df)
                
                if self.spark.catalog.tableExists(table_name):
                    logging.info(f"⚙️ [BRONZE] Actualizando tabla existente '{table_name}' con desduplicación...")
                    existing_df = self.spark.table(table_name)
                    combined_df = existing_df.unionByName(df_with_meta, allowMissingFiles=True)
                    dedup_df = combined_df.dropDuplicates(subset=primary_keys)
                    dedup_df.write.format("delta").mode("overwrite").option("overwriteSchema", "true").saveAsTable(table_name)
                    logging.info(f"✅ [BRONZE OK] Tabla '{table_name}' actualizada ({dedup_df.count()} registros totales).")
                else:
                    logging.info(f"⚙️ [BRONZE] Creando tabla inicial '{table_name}'...")
                    df_with_meta.write.format("delta").mode("overwrite").option("overwriteSchema", "true").saveAsTable(table_name)
                    logging.info(f"✅ [BRONZE OK] Tabla inicial '{table_name}' creada.")

            except Exception as e:
                logging.error(f"❌ Error al promocionar {raw_path} a {table_name}: {e}")

    def promote_realtime_to_bronze(self) -> None:
        sources = [
            ("Files/raw/realtime/nasa_nrt", "bronze_nasa_nrt", ["latitude", "longitude", "acq_date", "acq_time"]),
            ("Files/raw/realtime/weather", "bronze_weather", ["latitude", "longitude", "time"]),
            ("Files/raw/realtime/dgt_traffic", "bronze_dgt_traffic", ["record_id", "creation_time"])
        ]
        self._process_source_list(sources)

    def promote_batch_to_bronze(self) -> None:
        sources = [
            ("Files/raw/batch/nasa_historical", "bronze_nasa_historical", ["latitude", "longitude", "acq_date", "acq_time"]),
            ("Files/raw/batch/osm_roads", "bronze_osm_roads", ["id"])
        ]
        self._process_source_list(sources)