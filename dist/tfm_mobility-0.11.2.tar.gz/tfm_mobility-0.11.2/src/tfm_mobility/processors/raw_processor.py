import logging
import os
import xml.etree.ElementTree as ET
from typing import Optional
from pyspark.sql import SparkSession

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

class RawProcessor:
    """Procesador para convertir ficheros Landing (JSON/CSV/XML) a Parquet estructurado en RAW."""

    def __init__(self, spark: SparkSession):
        self.spark = spark

    def _clean_spark_path(self, path: str) -> str:
        """Limpia cualquier ruta dejando el formato 'Files/...' que exige PySpark en Fabric."""
        if not path:
            return ""
        clean = os.path.normpath(path).replace("\\", "/")
        for prefix in ["/lakehouse/default/", "lakehouse/default/", "/Files/"]:
            if clean.startswith(prefix):
                clean = clean[len(prefix):]
        if not clean.startswith("Files/"):
            clean = f"Files/{clean.lstrip('/')}"
        return clean

    def _clean_local_path(self, path: str) -> str:
        """Asegura el formato '/lakehouse/default/Files/...' que exige Python nativo."""
        if not path:
            return ""
        clean = os.path.normpath(path).replace("\\", "/")
        if not clean.startswith("/lakehouse/default/"):
            if clean.startswith("Files/"):
                return f"/lakehouse/default/{clean}"
            return f"/lakehouse/default/Files/{clean.lstrip('/')}"
        return clean

    def landing_to_raw_csv(self, landing_path: str, raw_path: Optional[str] = None, is_batch: bool = False) -> None:
        """Lee un archivo CSV de Landing y lo guarda como Parquet en RAW."""
        spark_landing = self._clean_spark_path(landing_path)
        spark_raw = self._clean_spark_path(raw_path or "Files/raw/realtime/csv_data")
        
        logging.info(f"📄 Leyendo CSV Landing (is_batch={is_batch}): {spark_landing}")
        df = self.spark.read.option("header", "true").option("inferSchema", "true").csv(spark_landing)
        df.write.format("parquet").mode("overwrite").save(spark_raw)
        logging.info(f"✅ Convertido a Parquet RAW en: {spark_raw}")

    def landing_to_raw_json(self, landing_path: str, raw_path: Optional[str] = None, is_batch: bool = False) -> None:
        """Lee un archivo JSON de Landing y lo guarda como Parquet en RAW."""
        spark_landing = self._clean_spark_path(landing_path)
        spark_raw = self._clean_spark_path(raw_path or "Files/raw/realtime/json_data")
        
        logging.info(f"📄 Leyendo JSON Landing (is_batch={is_batch}): {spark_landing}")
        df = self.spark.read.option("multiline", "true").json(spark_landing)
        df.write.format("parquet").mode("overwrite").save(spark_raw)
        logging.info(f"✅ Convertido a Parquet RAW en: {spark_raw}")

    def landing_to_raw_osm(self, landing_path: str, raw_path: Optional[str] = None) -> None:
        """Lee la red viaria de OSM en JSON y la promociona a Parquet RAW."""
        target_raw = raw_path or "Files/raw/batch/osm_roads"
        self.landing_to_raw_json(landing_path, target_raw, is_batch=True)

    def landing_to_raw_dgt_xml(self, landing_path: str, raw_path: Optional[str] = None) -> None:
        """Parsea XML de DGT Tráfico e incidencias y lo promociona a Parquet RAW."""
        local_landing = self._clean_local_path(landing_path)
        spark_raw = self._clean_spark_path(raw_path or "Files/raw/realtime/dgt_traffic")
        
        logging.info(f"📄 Procesando XML DGT Landing: {local_landing}")
        tree = ET.parse(local_landing)
        root = tree.getroot()
        
        records = []
        for elem in root.iter():
            if elem.attrib or elem.text:
                row = {child.tag: child.text.strip() for child in elem if child.text}
                if row:
                    records.append(row)
                    
        if records:
            df = self.spark.createDataFrame(records)
            df.write.format("parquet").mode("overwrite").save(spark_raw)
            logging.info(f"✅ XML DGT convertido a Parquet RAW en: {spark_raw}")
        else:
            logging.warning(f"⚠️ XML DGT sin registros parseables: {landing_path}")