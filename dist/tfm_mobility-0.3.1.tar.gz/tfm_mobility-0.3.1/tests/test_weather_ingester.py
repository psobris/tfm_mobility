import os
import json
from unittest.mock import patch
from tfm_mobility.ingesters.realtime.weather_ingester import WeatherIngester

@patch("tfm_mobility.utils.api_client.APIClient.get_json")
def test_weather_ingester_landing_success(mock_get_json, tmp_path):
    fake_weather = {
        "current": {
            "temperature_2m": 32.5,
            "wind_speed_10m": 18.2,
            "precipitation": 0.0
        }
    }
    mock_get_json.return_value = fake_weather

    ingester = WeatherIngester(base_landing_path=str(tmp_path))
    result_path = ingester.fetch_to_landing()

    assert result_path is not None
    assert os.path.exists(result_path)

    with open(result_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    assert "current" in data
    assert data["current"]["temperature_2m"] == 32.5