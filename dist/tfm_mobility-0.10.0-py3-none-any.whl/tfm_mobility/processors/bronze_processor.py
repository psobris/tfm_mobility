import logging
from pyspark.sql import SparkSession
from pyspark.sql import functions as F

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

class BronzeProcessor:
    """Procesador para la capa Bronze que acumula histórico (Append + Deduplicate)."""

    def __init__(self, spark: SparkSession):
        self.spark = spark

    def _append_ingestion_metadata(self, df):
        """Añade la marca temporal exacta de inserción en el Data Lake."""
        return df.withColumn("ingestion_timestamp", F.current_timestamp())

    def promote_realtime_to_bronze(self) -> None:
        sources = [
            ("Files/raw/realtime/nasa_nrt", "bronze_nasa_nrt", ["latitude", "longitude", "acq_date", "acq_time"]),
            ("Files/raw/realtime/weather", "bronze_weather", ["latitude", "longitude", "time"]),
            ("Files/raw/realtime/dgt_traffic", "bronze_dgt_traffic", ["record_id", "creation_time"])
        ]
        
        for raw_path, table_name, primary_keys in sources:
            try:
                logging.info(f"⚙️ [BRONZE] Leyendo Parquet desde {raw_path}...")
                df = self.spark.read.parquet(raw_path)
                df_with_meta = self._append_ingestion_metadata(df)
                
                # Comprobamos si la tabla Delta ya existe para hacer APPEND o crearla
                if self.spark.catalog.tableExists(table_name):
                    logging.info(f"⚙️ [BRONZE] Añadiendo datos a la tabla existente '{table_name}' (Append)...")
                    existing_df = self.spark.table(table_name)
                    
                    # Unimos los nuevos datos con los existentes y desduplicamos por clave primaria
                    combined_df = existing_df.unionByName(df_with_meta, allowMissingFiles=True)
                    dedup_df = combined_df.dropDuplicates(subset=primary_keys)
                    
                    dedup_df.write.format("delta").mode("overwrite").option("overwriteSchema", "true").saveAsTable(table_name)
                    logging.info(f"✅ [BRONZE OK] Tabla '{table_name}' actualizada con histórico acumulado ({dedup_df.count()} filas).")
                else:
                    logging.info(f"⚙️ [BRONZE] Creando tabla inicial '{table_name}'...")
                    df_with_meta.write.format("delta").mode("overwrite").option("overwriteSchema", "true").saveAsTable(table_name)
                    logging.info(f"✅ [BRONZE OK] Tabla inicial '{table_name}' creada.")

            except Exception as e:
                logging.error(f"❌ Error al promocionar {raw_path} a {table_name}: {e}")

    def promote_batch_to_bronze(self) -> None:
        sources = [
            ("Files/raw/batch/nasa_historical", "bronze_nasa_historical", ["latitude", "longitude", "acq_date", "acq_time"]),
            ("Files/raw/batch/osm_roads", "bronze_osm_roads", ["id"])
        ]
        
        for raw_path, table_name, primary_keys in sources:
            try:
                logging.info(f"⚙️ [BRONZE] Leyendo Parquet desde {raw_path}...")
                df = self.spark.read.parquet(raw_path)
                df_with_meta = self._append_ingestion_metadata(df)
                
                if self.spark.catalog.tableExists(table_name):
                    existing_df = self.spark.table(table_name)
                    combined_df = existing_df.unionByName(df_with_meta, allowMissingFiles=True)
                    dedup_df = combined_df.dropDuplicates(subset=primary_keys)
                    dedup_df.write.format("delta").mode("overwrite").option("overwriteSchema", "true").saveAsTable(table_name)
                else:
                    df_with_meta.write.format("delta").mode("overwrite").option("overwriteSchema", "true").saveAsTable(table_name)
                logging.info(f"✅ [BRONZE OK] Tabla '{table_name}' actualizada.")
            except Exception as e:
                logging.error(f"❌ Error al promocionar {raw_path} a {table_name}: {e}")