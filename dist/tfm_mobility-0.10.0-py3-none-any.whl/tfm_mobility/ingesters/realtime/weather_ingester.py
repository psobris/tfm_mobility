import logging
import os
import time
from datetime import datetime
import requests
import pandas as pd
import numpy as np
from typing import Optional, List, Dict, Any

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

VERSION = "0.9.0"

def generate_spain_grid(step: float = 0.8) -> List[Dict[str, float]]:
    """Genera una malla uniforme de coordenadas (Lat/Lon) cubriendo España."""
    lat_min, lat_max = 36.0, 43.5
    lon_min, lon_max = -9.0, 3.0
    
    lats = np.arange(lat_min, lat_max + step, step)
    lons = np.arange(lon_min, lon_max + step, step)
    
    grid = []
    for lat in lats:
        for lon in lons:
            grid.append({
                "lat": round(float(lat), 4),
                "lon": round(float(lon), 4)
            })
    return grid

class WeatherIngestor:
    """Ingestor meteorológico nacional v0.9.0."""

    BASE_URL = "https://api.open-meteo.com/v1/forecast"

    def __init__(self, step_degrees: float = 0.8):
        self.grid = generate_spain_grid(step=step_degrees)

    def fetch_forecast(self, forecast_days: int = 7, batch_size: int = 10) -> Optional[pd.DataFrame]:
        logging.info(f"🌤️ [WEATHER v{VERSION}] Extracción nacional. Malla total: {len(self.grid)} puntos.")
        
        all_dfs = []
        for i in range(0, len(self.grid), batch_size):
            batch = self.grid[i:i + batch_size]
            lats = ",".join([str(p["lat"]) for p in batch])
            lons = ",".join([str(p["lon"]) for p in batch])
            
            params = {
                "latitude": lats,
                "longitude": lons,
                "hourly": "temperature_2m,relative_humidity_2m,precipitation_probability,precipitation,rain,showers,snowfall,wind_speed_10m,wind_gusts_10m",
                "forecast_days": forecast_days,
                "timezone": "Europe/Madrid"
            }
            
            try:
                response = requests.get(self.BASE_URL, params=params, timeout=30)
                response.raise_for_status()
                data = response.json()
                
                results = data if isinstance(data, list) else [data]
                for item in results:
                    hourly = item.get("hourly", {})
                    if hourly:
                        df_item = pd.DataFrame(hourly)
                        df_item["latitude"] = item.get("latitude")
                        df_item["longitude"] = item.get("longitude")
                        df_item["elevation"] = item.get("elevation", 0)
                        all_dfs.append(df_item)
                
                time.sleep(0.1)

            except Exception as e:
                logging.error(f"⚠️ [WEATHER v{VERSION}] Error lote {i//batch_size + 1}: {e}")
                continue

        if not all_dfs:
            logging.error(f"❌ [WEATHER v{VERSION}] No se obtuvieron datos.")
            return None
            
        combined_df = pd.concat(all_dfs, ignore_index=True)
        logging.info(f"✅ [WEATHER OK v{VERSION}] {len(combined_df)} filas obtenidas para España.")
        return combined_df

    def fetch_stream_to_landing(self, landing_base_dir: str = "/lakehouse/default/Files/landing/realtime/weather") -> Optional[str]:
        df = self.fetch_forecast()
        if df is None or df.empty:
            return None
            
        now = datetime.now()
        year_str = now.strftime("%Y")
        month_str = now.strftime("%m")
        day_str = now.strftime("%d")
        hour_str = now.strftime("%H")

        # Jerarquía de subcarpetas YYYY/MM/DD/HH estandarizada
        partitioned_dir = os.path.join(landing_base_dir, year_str, month_str, day_str, hour_str)
        os.makedirs(partitioned_dir, exist_ok=True)

        timestamp_str = now.strftime("%Y%m%d_%H%M%S")
        file_path = os.path.join(partitioned_dir, f"weather_{timestamp_str}.json")
        
        df.to_json(file_path, orient="records", date_format="iso")
        logging.info(f"💾 [WEATHER LANDING] Grid nacional guardado en: {file_path}")
        return file_path