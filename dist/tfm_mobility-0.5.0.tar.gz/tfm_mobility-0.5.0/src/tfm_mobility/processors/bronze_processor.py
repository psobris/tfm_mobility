import logging
from pyspark.sql import SparkSession

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

class BronzeProcessor:
    """Procesador para promocionar archivos Parquet de RAW a Tablas Delta en Bronze."""

    def __init__(self, spark: SparkSession):
        self.spark = spark

    def raw_to_bronze_table(self, raw_parquet_path: str, table_name: str, mode: str = "overwrite"):
        try:
            logging.info(f"⚙️ [BRONZE] Leyendo Parquet de RAW desde {raw_parquet_path}...")
            
            # Formatear la ruta asegurando prefijo /lakehouse/default/
            clean_path = raw_parquet_path.replace("/lakehouse/default/", "").replace("\\", "/")
            full_path = f"/lakehouse/default/{clean_path}"
            
            df = self.spark.read.parquet(full_path)
            
            total_records = df.count()
            logging.info(f"⚙️ [BRONZE] Guardando {total_records} registros en Tabla Delta: '{table_name}'...")
            
            # Guardar en la sección Tables de Fabric
            df.write.format("delta") \
                .mode(mode) \
                .option("overwriteSchema", "true") \
                .saveAsTable(f"default.{table_name}")
            
            logging.info(f"✅ [BRONZE OK] Tabla Delta '{table_name}' creada/actualizada con éxito.")
            return True
        except Exception as e:
            logging.error(f"❌ Error al crear la tabla Bronze '{table_name}': {e}")
            raise e  # Lanzar excepción para que Fabric detecte el fallo si ocurre

    def promote_all_raw_to_bronze(self):
        datasets = [
            ("Files/raw/realtime/nasa_nrt", "bronze_nasa_nrt"),
            ("Files/raw/realtime/weather", "bronze_weather"),
            ("Files/raw/realtime/dgt_traffic", "bronze_dgt_traffic"),
            ("Files/raw/batch/nasa_historical", "bronze_nasa_historical"),
            ("Files/raw/batch/osm_networks", "bronze_osm_roads"),
            ("Files/raw/batch/osm_places", "bronze_osm_places")
        ]
        
        logging.info("🚀 [BRONZE] Iniciando promoción global de RAW a Tablas Delta en Bronze...")
        for raw_path, table_name in datasets:
            try:
                self.raw_to_bronze_table(raw_path, table_name)
            except Exception as e:
                logging.warning(f"⚠️ Omitiendo o fallando en {table_name}: {e}")