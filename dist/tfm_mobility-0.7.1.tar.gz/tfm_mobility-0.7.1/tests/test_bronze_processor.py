from unittest.mock import MagicMock, patch
from tfm_mobility.processors.bronze_processor import BronzeProcessor

def test_raw_to_bronze_table_success():
    # Mock de SparkSession y DataFrames
    mock_spark = MagicMock()
    mock_df = MagicMock()
    mock_spark.read.parquet.return_value = mock_df
    mock_df.count.return_value = 100
    
    # Mock para el encadenamiento .write.format().mode().option().saveAsTable()
    mock_writer = MagicMock()
    mock_df.write.format.return_value = mock_writer
    mock_writer.mode.return_value = mock_writer
    mock_writer.option.return_value = mock_writer
    
    processor = BronzeProcessor(mock_spark)
    result = processor.raw_to_bronze_table("Files/raw/realtime/nasa_nrt", "bronze_nasa_nrt")
    
    assert result is True
    mock_spark.read.parquet.assert_called_once_with("/lakehouse/default/Files/raw/realtime/nasa_nrt")
    mock_writer.saveAsTable.assert_called_once_with("default.bronze_nasa_nrt")

@patch.object(BronzeProcessor, 'raw_to_bronze_table')
def test_promote_realtime_to_bronze(mock_raw_to_bronze):
    mock_spark = MagicMock()
    processor = BronzeProcessor(mock_spark)
    
    processor.promote_realtime_to_bronze()
    
    # Debe llamar 3 veces (NASA NRT, Weather, DGT Traffic)
    assert mock_raw_to_bronze.call_count == 3

@patch.object(BronzeProcessor, 'raw_to_bronze_table')
def test_promote_batch_to_bronze(mock_raw_to_bronze):
    mock_spark = MagicMock()
    processor = BronzeProcessor(mock_spark)
    
    processor.promote_batch_to_bronze()
    
    # Debe llamar 3 veces (NASA Histórico, OSM Roads, OSM Places)
    assert mock_raw_to_bronze.call_count == 3