import os
import logging
import requests
from datetime import datetime

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

class OSMIngester:
    """Ingester Batch para la red de carreteras de OpenStreetMap."""

    def __init__(self, base_landing_path: str = "Files/landing/batch/osm_networks"):
        self.base_landing_path = base_landing_path.replace("/lakehouse/default/", "")
        self.url = "https://overpass-api.de/api/interpreter"

    def fetch_batch_to_landing(self) -> str:
        logging.info("📦 [BATCH] Consultando infraestructura vial en OpenStreetMap...")
        query = """
        [out:json][timeout:60];
        (
          way["highway"~"motorway|trunk|primary"](40.30,-3.85,40.50,-3.55);
        );
        out body;
        """
        headers = {"User-Agent": "TFM_Mobility_App/1.0"}
        try:
            r = requests.post(self.url, data={"data": query}, headers=headers, timeout=60)
            if r.status_code != 200 or len(r.text) < 10:
                logging.error(f"❌ Error HTTP {r.status_code} al consultar OSM.")
                return None
            raw_data = r.text
        except Exception as e:
            logging.error(f"❌ Excepción en la ingesta OSM: {e}")
            return None

        now = datetime.now()
        dir_dest = os.path.join(self.base_landing_path, now.strftime("%Y"), now.strftime("%m"), now.strftime("%d"))
        local_dir = os.path.join("/lakehouse/default", dir_dest) if not dir_dest.startswith("/lakehouse/default") else dir_dest
        os.makedirs(local_dir, exist_ok=True)

        file_name = f"osm_roads_{now.strftime('%Y%m%d_%H%M%S')}.json"
        local_file_path = os.path.join(local_dir, file_name)

        with open(local_file_path, "w", encoding="utf-8") as f:
            f.write(raw_data)

        spark_file_path = os.path.join(dir_dest, file_name).replace("\\", "/")
        logging.info(f"📥 [LANDING OK] Red OSM guardada en: {spark_file_path}")
        return spark_file_path