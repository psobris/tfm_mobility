import os
import json
import logging
import xml.etree.ElementTree as ET

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

class RawProcessor:
    """Procesador para promocionar ficheros de Landing a la capa RAW (Parquet)."""

    def __init__(self, spark):
        self.spark = spark

    def _sanitize_path(self, path: str) -> str:
        if not path:
            return path
        return path.replace("/lakehouse/default/", "").replace("\\", "/")

    def landing_to_raw_csv(self, landing_path: str, dataset_name: str, is_batch: bool = False):
        clean_path = self._sanitize_path(landing_path)
        subfolder = "batch" if is_batch else "realtime"
        target_path = f"Files/raw/{subfolder}/{dataset_name}"
        
        logging.info(f"⚙️ [RAW] Promocionando CSV desde {clean_path}...")
        df = self.spark.read.option("header", "true").csv(clean_path)
        df.write.mode("append" if not is_batch else "overwrite").parquet(target_path)
        logging.info(f"✅ [RAW OK] CSV guardado en {target_path}")

    def landing_to_raw_json(self, landing_path: str, dataset_name: str, is_batch: bool = False):
        clean_path = self._sanitize_path(landing_path)
        subfolder = "batch" if is_batch else "realtime"
        target_path = f"Files/raw/{subfolder}/{dataset_name}"

        logging.info(f"⚙️ [RAW] Promocionando JSON desde {clean_path}...")
        df = self.spark.read.json(clean_path)
        df.write.mode("append" if not is_batch else "overwrite").parquet(target_path)
        logging.info(f"✅ [RAW OK] JSON guardado en {target_path}")

    def landing_to_raw_dgt_xml(self, landing_path: str):
        clean_path = self._sanitize_path(landing_path)
        local_xml_path = os.path.join("/lakehouse/default", clean_path)
        
        logging.info(f"⚙️ [RAW] Parseando XML DGT desde {local_xml_path}...")
        with open(local_xml_path, "r", encoding="utf-8") as f:
            xml_content = f.read()

        root = ET.fromstring(xml_content)
        records = root.findall(".//{*}situationRecord")
        
        parsed_rows = []
        for rec in records:
            def get_text(tag_name):
                elem = rec.find(f".//{{*}}{tag_name}")
                return elem.text.strip() if elem is not None and elem.text else None

            row = {
                "record_id": rec.attrib.get("id", "N/A"),
                "creation_time": get_text("situationRecordCreationTime"),
                "cause_type": get_text("causeType"),
                "road_name": get_text("roadName"),
                "province": get_text("province"),
                "municipality": get_text("municipality"),
                "kilometer_point": float(get_text("kilometerPoint")) if get_text("kilometerPoint") else None,
                "latitude": float(get_text("latitude")) if get_text("latitude") else None,
                "longitude": float(get_text("longitude")) if get_text("longitude") else None,
                "management_type": get_text("roadOrCarriagewayOrLaneManagementType")
            }
            parsed_rows.append(row)

        df_dgt = self.spark.createDataFrame(parsed_rows)
        target_path = "Files/raw/realtime/dgt_traffic"
        df_dgt.write.mode("append").parquet(target_path)
        logging.info(f"✅ [RAW OK] DGT Traffic parseado y guardado en {target_path}")

    def landing_to_raw_osm(self, landing_path: str):
        clean_path = self._sanitize_path(landing_path)
        local_file_path = os.path.join("/lakehouse/default", clean_path)
        
        logging.info(f"⚙️ [RAW] Parseando OSM roads desde {local_file_path}...")
        with open(local_file_path, "r", encoding="utf-8") as f:
            osm_data = json.load(f)

        elements = osm_data.get("elements", [])
        rows = []
        for el in elements:
            tags = el.get("tags", {})
            rows.append({
                "id": el.get("id"),
                "type": el.get("type"),
                "highway": tags.get("highway"),
                "name": tags.get("name"),
                "ref": tags.get("ref"),
                "maxspeed": tags.get("maxspeed"),
                "lanes": tags.get("lanes"),
                "nodes_count": len(el.get("nodes", []))
            })

        df_osm = self.spark.createDataFrame(rows)
        target_path = "Files/raw/batch/osm_networks"
        df_osm.write.mode("overwrite").parquet(target_path)
        logging.info(f"✅ [RAW OK] OSM Infrastructure guardado en {target_path}")