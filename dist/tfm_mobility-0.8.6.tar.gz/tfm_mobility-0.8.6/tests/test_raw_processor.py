from unittest.mock import MagicMock
from tfm_mobility.processors.raw_processor import RawProcessor

def test_raw_processor_sanitize_paths():
    mock_spark = MagicMock()
    processor = RawProcessor(mock_spark)

    dirty_path = "Files/landing/realtime/test.csv"
    read_path = processor._sanitize_read_path(dirty_path)
    write_path = processor._sanitize_write_path(dirty_path)

    assert read_path == "/lakehouse/default/Files/landing/realtime/test.csv"
    assert write_path == "/lakehouse/default/Files/landing/realtime/test.csv"

def test_raw_processor_optional_raw_path():
    mock_spark = MagicMock()
    processor = RawProcessor(mock_spark)
    
    try:
        processor.landing_to_raw_osm("invalid_path.json")
        processor.landing_to_raw_dgt_xml("invalid_path.xml")
    except Exception as e:
        assert False, f"Error al ejecutar métodos: {e}"