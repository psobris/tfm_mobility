import os
import logging
import json
from datetime import datetime
from tfm_mobility.utils.api_client import APIClient

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

class WeatherIngester:
    """Ingester para datos meteorológicos de la zona de emergencia/evacuación."""

    def __init__(self, base_landing_path: str = "/lakehouse/default/Files/landing/weather"):
        self.client = APIClient()
        self.base_landing_path = base_landing_path
        self.weather_url = (
            "https://api.open-meteo.com/v1/forecast?"
            "latitude=40.4168&longitude=-3.7038&"
            "current=temperature_2m,relative_humidity_2m,wind_speed_10m,wind_direction_10m,precipitation"
        )

    def fetch_to_landing(self) -> str:
        logging.info("📡 Descargando datos meteorológicos hacia LANDING...")
        raw_json = self.client.get_json(self.weather_url)

        if not raw_json or "current" not in raw_json:
            logging.error("❌ Fallo al obtener datos meteorológicos válidos.")
            return None

        now = datetime.now()
        year_str = now.strftime("%Y")
        month_str = now.strftime("%m")
        day_str = now.strftime("%d")
        hour_str = now.strftime("%H")  # 👈 🆕 Partición por hora

        # Construcción de la ruta: base / YYYY / MM / DD / HH /
        dir_dest = os.path.join(self.base_landing_path, year_str, month_str, day_str, hour_str)
        os.makedirs(dir_dest, exist_ok=True)

        # ⏱️ Nombre de archivo con timestamp: weather_YYYYMMDD_HHMMSS.json
        timestamp_str = now.strftime("%Y%m%d_%H%M%S")
        file_name = f"weather_{timestamp_str}.json"
        file_path = os.path.join(dir_dest, file_name)

        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(raw_json, f, indent=2)

        logging.info(f"📥 [LANDING OK] Datos de clima guardados en: {file_path}")
        return file_path