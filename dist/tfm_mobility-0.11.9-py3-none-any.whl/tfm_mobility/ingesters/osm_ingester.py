import logging
import os
import json
from datetime import datetime
import requests
from typing import Optional, Dict, Any

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

OVERPASS_ENDPOINTS = [
    "https://overpass-api.de/api/interpreter",
    "https://overpass.kumi.systems/api/interpreter",
    "https://maps.mail.ru/osm/tools/overpass/api/interpreter"
]

class OSMIngester:
    """Ingestor para la red viaria de España desde OpenStreetMap (Overpass API)."""

    def __init__(self, bbox: str = "35.8,-9.3,43.8,3.3", **kwargs):
        self.bbox = bbox

    def fetch_roads(self) -> Optional[Dict[str, Any]]:
        # Query optimizada para carreteras principales de España
        query = f"""
        [out:json][timeout:60];
        (
          way["highway"~"motorway|trunk"]({self.bbox});
        );
        out body qt 5000;
        """
        
        headers = {
            "User-Agent": "TFMMobilityApp/1.0 (contact: pasobrad@ucm.es)",
            "Accept": "application/json"
        }

        for endpoint in OVERPASS_ENDPOINTS:
            try:
                logging.info(f"🗺️ [OSM] Solicitando carreteras a Overpass: {endpoint}...")
                response = requests.post(endpoint, data={"data": query}, headers=headers, timeout=65)
                
                if response.status_code == 200:
                    data = response.json()
                    logging.info(f"✅ [OSM OK] Obtenidos {len(data.get('elements', []))} tramos de carretera.")
                    return data
                else:
                    logging.warning(f"⚠️ [OSM WARNING] Servidor {endpoint} devolvió código: {response.status_code}")
            except Exception as e:
                logging.warning(f"⚠️ [OSM WARNING] Falló endpoint {endpoint}: {e}")
                continue

        logging.error("❌ [OSM ERROR] Fallaron todos los endpoints de Overpass.")
        return None

    def fetch_stream_to_landing(self, landing_dir: str = "/lakehouse/default/Files/landing/batch/osm_roads") -> Optional[str]:
        """Guarda la respuesta JSON de OSM en la zona Landing Batch."""
        data = self.fetch_roads()
        if not data:
            return None

        os.makedirs(landing_dir, exist_ok=True)
        timestamp_str = datetime.now().strftime("%Y%m%d_%H%M%S")
        file_path = os.path.join(landing_dir, f"osm_roads_{timestamp_str}.json")

        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False)

        logging.info(f"💾 [OSM LANDING] Red viaria guardada en: {file_path}")
        return file_path

    def fetch_batch_to_landing(self, landing_dir: str = "/lakehouse/default/Files/landing/batch/osm_roads") -> Optional[str]:
        """Alias de compatibilidad para cuadernos batch."""
        return self.fetch_stream_to_landing(landing_dir=landing_dir)