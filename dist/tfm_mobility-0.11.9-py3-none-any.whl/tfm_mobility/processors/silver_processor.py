import logging
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import DoubleType, IntegerType, DateType

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

# Bounding Box Regional Transfronterizo:
# España + Portugal + Sur de Francia + Norte de Marruecos + Archipiélagos
LAT_MIN, LAT_MAX = 27.5, 45.0
LON_MIN, LON_MAX = -18.5, 7.5

class SilverProcessor:
    """Limpieza, filtrado geoespacial transfronterizo y estandarización para la capa Silver."""

    def __init__(self, spark: SparkSession):
        self.spark = spark

    def _filter_regional_bbox(self, df, lat_col="latitude", lon_col="longitude"):
        """Aplica el filtro geoespacial regional para la Ibérica, Sur de Francia y Norte de Marruecos."""
        return df.filter(
            (F.col(lat_col) >= LAT_MIN) & (F.col(lat_col) <= LAT_MAX) &
            (F.col(lon_col) >= LON_MIN) & (F.col(lon_col) <= LON_MAX)
        )

    def process_nasa_historical(self) -> None:
        """Limpia NASA Histórico: Casteo de tipos numéricos y filtrado transfronterizo."""
        try:
            df = self.spark.table("bronze_nasa_historical")
            
            # 1. Casteo explícito de tipos
            df_clean = df.withColumn("latitude", F.col("latitude").cast(DoubleType())) \
                         .withColumn("longitude", F.col("longitude").cast(DoubleType())) \
                         .withColumn("bright_ti4", F.col("bright_ti4").cast(DoubleType())) \
                         .withColumn("bright_ti5", F.col("bright_ti5").cast(DoubleType())) \
                         .withColumn("frp", F.col("frp").cast(DoubleType())) \
                         .withColumn("scan", F.col("scan").cast(DoubleType())) \
                         .withColumn("track", F.col("track").cast(DoubleType())) \
                         .withColumn("acq_date", F.col("acq_date").cast(DateType())) \
                         .withColumn("acq_time", F.col("acq_time").cast(IntegerType()))

            # 2. Filtrado geoespacial ampliado
            df_regional = self._filter_regional_bbox(df_clean)

            df_regional.write.format("delta").mode("overwrite").option("overwriteSchema", "true").saveAsTable("silver_nasa_historical")
            logging.info(f"✅ [SILVER OK] 'silver_nasa_historical' creada con {df_regional.count()} registros transfronterizos.")
        except Exception as e:
            logging.error(f"❌ Error al procesar Silver NASA Historical: {e}")

    def process_nasa_nrt(self) -> None:
        """Filtra NASA NRT con la cobertura regional ampliada."""
        try:
            df = self.spark.table("bronze_nasa_nrt")
            df_regional = self._filter_regional_bbox(df)

            df_regional.write.format("delta").mode("overwrite").option("overwriteSchema", "true").saveAsTable("silver_nasa_nrt")
            logging.info(f"✅ [SILVER OK] 'silver_nasa_nrt' creada con {df_regional.count()} registros transfronterizos.")
        except Exception as e:
            logging.error(f"❌ Error al procesar Silver NASA NRT: {e}")

    def process_weather(self) -> None:
        """Estandariza los tipos temporales y limpia lecturas nulas en Weather."""
        try:
            df = self.spark.table("bronze_weather")
            
            df_clean = df.withColumn("forecast_timestamp", F.to_timestamp("time", "yyyy-MM-dd'T'HH:mm")) \
                         .drop("time")
            
            df_clean.write.format("delta").mode("overwrite").option("overwriteSchema", "true").saveAsTable("silver_weather")
            logging.info(f"✅ [SILVER OK] 'silver_weather' creada con {df_clean.count()} registros depurados.")
        except Exception as e:
            logging.error(f"❌ Error al procesar Silver Weather: {e}")

    def process_dgt_traffic(self) -> None:
        """Estandariza el XML parseado de DGT eliminando campos nulos y filtrando coordenadas regionales."""
        try:
            df = self.spark.table("bronze_dgt_traffic")
            
            df_clean = self._filter_regional_bbox(df).drop("maintenance_type")  # Columna con 100% nulos

            df_clean.write.format("delta").mode("overwrite").option("overwriteSchema", "true").saveAsTable("silver_dgt_traffic")
            logging.info(f"✅ [SILVER OK] 'silver_dgt_traffic' creada con {df_clean.count()} registros depurados.")
        except Exception as e:
            logging.error(f"❌ Error al procesar Silver DGT Traffic: {e}")

    def process_all(self) -> None:
        self.process_nasa_historical()
        self.process_nasa_nrt()
        self.process_weather()
        self.process_dgt_traffic()