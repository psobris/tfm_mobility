import logging
import os
import xml.etree.ElementTree as ET
from typing import Optional
from pyspark.sql import SparkSession

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

class RawProcessor:
    """Procesador para convertir ficheros Landing (JSON/CSV/XML) a Parquet estructurado en RAW."""

    def __init__(self, spark: SparkSession):
        self.spark = spark

    def _sanitize_path(self, path: str) -> str:
        """Saneador de rutas compatible con OneLake y sistemas POSIX."""
        if not path:
            return ""
        clean = os.path.normpath(path).replace("\\", "/")
        # Mantiene la ruta completa de lakehouse para evitar error 400 en OneLake ABFS
        if not clean.startswith("/lakehouse/default/") and clean.startswith("Files/"):
            return f"/lakehouse/default/{clean}"
        return clean

    def landing_to_raw_csv(self, landing_path: str, raw_path: str, is_batch: bool = False) -> None:
        """Lee un archivo CSV de Landing y lo guarda como Parquet en RAW."""
        try:
            clean_landing = self._sanitize_path(landing_path)
            clean_raw = self._sanitize_path(raw_path)
            
            logging.info(f"📄 Leyendo CSV Landing (is_batch={is_batch}): {clean_landing}")
            df = self.spark.read.option("header", "true").option("inferSchema", "true").csv(clean_landing)
            
            os.makedirs(clean_raw, exist_ok=True)
            df.write.format("parquet").mode("overwrite").save(clean_raw)
            logging.info(f"✅ Convertido a Parquet RAW en: {clean_raw}")
        except Exception as e:
            logging.error(f"❌ Error al convertir CSV a RAW ({landing_path}): {e}")

    def landing_to_raw_json(self, landing_path: str, raw_path: str, is_batch: bool = False) -> None:
        """Lee un archivo JSON de Landing y lo guarda como Parquet en RAW."""
        try:
            clean_landing = self._sanitize_path(landing_path)
            clean_raw = self._sanitize_path(raw_path)
            
            logging.info(f"📄 Leyendo JSON Landing (is_batch={is_batch}): {clean_landing}")
            df = self.spark.read.option("multiline", "true").json(clean_landing)
            
            os.makedirs(clean_raw, exist_ok=True)
            df.write.format("parquet").mode("overwrite").save(clean_raw)
            logging.info(f"✅ Convertido a Parquet RAW en: {clean_raw}")
        except Exception as e:
            logging.error(f"❌ Error al convertir JSON a RAW ({landing_path}): {e}")

    def landing_to_raw_dgt_xml(self, landing_path: str, raw_path: str) -> None:
        """Parsea XML de DGT Tráfico e incidencias y lo promociona a Parquet RAW."""
        try:
            clean_landing = self._sanitize_path(landing_path)
            clean_raw = self._sanitize_path(raw_path)
            
            logging.info(f"📄 Procesando XML DGT Landing: {clean_landing}")
            tree = ET.parse(clean_landing)
            root = tree.getroot()
            
            records = []
            # Parseo genérico de nodos de incidencias/puntos de medida XML DGT
            for elem in root.iter():
                if elem.attrib or elem.text:
                    row = {child.tag: child.text.strip() for child in elem if child.text}
                    if row:
                        records.append(row)
                        
            if records:
                df = self.spark.createDataFrame(records)
                os.makedirs(clean_raw, exist_ok=True)
                df.write.format("parquet").mode("overwrite").save(clean_raw)
                logging.info(f"✅ XML DGT convertido a Parquet RAW en: {clean_raw}")
            else:
                logging.warning(f"⚠️ XML DGT sin registros parseables: {clean_landing}")
        except Exception as e:
            logging.error(f"❌ Error al convertir XML DGT a RAW ({landing_path}): {e}")

    def process_realtime_sources(self) -> None:
        """Procesa todas las fuentes NRT en Landing."""
        base_landing = "/lakehouse/default/Files/landing/realtime"
        base_raw = "/lakehouse/default/Files/raw/realtime"

        # 1. Weather (JSON)
        weather_landing = self._sanitize_path(os.path.join(base_landing, "weather"))
        if os.path.exists(weather_landing):
            files = [os.path.join(weather_landing, f) for f in os.listdir(weather_landing) if f.endswith(".json")]
            if files:
                self.landing_to_raw_json(sorted(files)[-1], os.path.join(base_raw, "weather"), is_batch=False)

        # 2. NASA NRT (CSV)
        nasa_landing = self._sanitize_path(os.path.join(base_landing, "nasa_nrt"))
        if os.path.exists(nasa_landing):
            csv_files = []
            for root, _, files in os.walk(nasa_landing):
                for f in files:
                    if f.endswith(".csv"):
                        csv_files.append(os.path.join(root, f))
            if csv_files:
                self.landing_to_raw_csv(sorted(csv_files)[-1], os.path.join(base_raw, "nasa_nrt"), is_batch=False)

        # 3. DGT Traffic (XML o JSON)
        dgt_landing = self._sanitize_path(os.path.join(base_landing, "dgt_traffic"))
        if os.path.exists(dgt_landing):
            for root, _, files in os.walk(dgt_landing):
                for f in files:
                    full_p = os.path.join(root, f)
                    if f.endswith(".xml"):
                        self.landing_to_raw_dgt_xml(full_p, os.path.join(base_raw, "dgt_traffic"))
                    elif f.endswith(".json"):
                        self.landing_to_raw_json(full_p, os.path.join(base_raw, "dgt_traffic"), is_batch=False)

    def process_batch_sources(self) -> None:
        """Procesa todas las fuentes Batch en Landing (OSM, NASA Histórico)."""
        base_landing = "/lakehouse/default/Files/landing/batch"
        base_raw = "/lakehouse/default/Files/raw/batch"

        # 1. OSM Roads (JSON)
        osm_landing = self._sanitize_path(os.path.join(base_landing, "osm_roads"))
        if os.path.exists(osm_landing):
            files = [os.path.join(osm_landing, f) for f in os.listdir(osm_landing) if f.endswith(".json")]
            if files:
                self.landing_to_raw_json(sorted(files)[-1], os.path.join(base_raw, "osm_roads"), is_batch=True)

        # 2. NASA Historical (CSV)
        nasa_hist_landing = self._sanitize_path(os.path.join(base_landing, "nasa_historical"))
        if os.path.exists(nasa_hist_landing):
            csv_files = []
            for root, _, files in os.walk(nasa_hist_landing):
                for f in files:
                    if f.endswith(".csv"):
                        csv_files.append(os.path.join(root, f))
            if csv_files:
                self.landing_to_raw_csv(sorted(csv_files)[-1], os.path.join(base_raw, "nasa_historical"), is_batch=True)