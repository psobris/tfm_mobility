import logging
from typing import List
from delta.tables import DeltaTable
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql import functions as F

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

class BronzeProcessor:
    """Procesador para la capa Bronze manteniendo la trazabilidad completa mediante Delta MERGE."""

    def __init__(self, spark: SparkSession):
        self.spark = spark

    def merge_into_bronze(self, raw_df: DataFrame, table_name: str, primary_keys: List[str]) -> None:
        if raw_df is None or raw_df.rdd.isEmpty():
            logging.warning(f"⚠️ El DataFrame de origen para {table_name} está vacío. Cancelando MERGE.")
            return

        # 1. Desduplicar el lote actual manteniendo metadatos
        dedup_raw_df = raw_df.dropDuplicates(subset=primary_keys)

        # 2. Ejecutar MERGE
        if self.spark.catalog.tableExists(table_name):
            delta_table = DeltaTable.forName(self.spark, table_name)
            merge_condition = " AND ".join([f"target.{col} = source.{col}" for col in primary_keys])

            delta_table.alias("target") \
                .merge(dedup_raw_df.alias("source"), merge_condition) \
                .whenNotMatchedInsertAll() \
                .execute()
                
            logging.info(f"✅ MERGE ejecutado en '{table_name}' preservando 'landing_source_file' e 'ingestion_timestamp'.")
        else:
            dedup_raw_df.write \
                .format("delta") \
                .mode("overwrite") \
                .option("overwriteSchema", "true") \
                .saveAsTable(table_name)
            logging.info(f"✨ Tabla Delta '{table_name}' creada por primera vez.")

    def promote_realtime_to_bronze(self) -> None:
        sources = [
            ("Files/raw/realtime/dgt_traffic", "bronze_dgt_traffic", ["record_id"]),
            ("Files/raw/realtime/nasa_nrt", "bronze_nasa_nrt", ["latitude", "longitude", "acq_date", "acq_time"]),
            ("Files/raw/realtime/weather", "bronze_weather", ["latitude", "longitude", "time"])
        ]

        for raw_path, table_name, pk in sources:
            try:
                raw_df = self.spark.read.parquet(raw_path)
                self.merge_into_bronze(raw_df, table_name, pk)
            except Exception as e:
                logging.error(f"❌ Error en MERGE Bronze {table_name}: {e}")

    def promote_batch_to_bronze(self) -> None:
        sources = [
            ("Files/raw/batch/nasa_historical", "bronze_nasa_historical", ["latitude", "longitude", "acq_date", "acq_time"]),
            ("Files/raw/batch/osm_roads", "bronze_osm_roads", ["id"])
        ]

        for raw_path, table_name, pk in sources:
            try:
                raw_df = self.spark.read.parquet(raw_path)
                self.merge_into_bronze(raw_df, table_name, pk)
            except Exception as e:
                logging.error(f"❌ Error en MERGE Bronze {table_name}: {e}")