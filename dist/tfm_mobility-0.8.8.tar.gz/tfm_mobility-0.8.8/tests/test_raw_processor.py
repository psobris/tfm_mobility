from unittest.mock import MagicMock
from tfm_mobility.processors.raw_processor import RawProcessor

def test_raw_processor_sanitize_paths():
    mock_spark = MagicMock()
    processor = RawProcessor(mock_spark)

    dirty_path = "/lakehouse/default/Files/landing/realtime/test.csv"
    spark_path = processor._sanitize_spark_path(dirty_path)
    local_path = processor._sanitize_local_path("Files/landing/realtime/test.csv")

    assert spark_path == "Files/landing/realtime/test.csv"
    assert local_path == "/lakehouse/default/Files/landing/realtime/test.csv"

def test_raw_processor_optional_raw_path():
    mock_spark = MagicMock()
    processor = RawProcessor(mock_spark)
    
    try:
        processor.landing_to_raw_osm("invalid_path.json")
        processor.landing_to_raw_dgt_xml("invalid_path.xml")
    except Exception as e:
        assert False, f"Error al ejecutar métodos: {e}"