import os
from unittest.mock import MagicMock
from tfm_mobility.processors.raw_processor import RawProcessor

def test_raw_processor_missing_csv():
    mock_spark = MagicMock()
    processor = RawProcessor(mock_spark)
    assert processor.landing_to_raw_csv("invalid/path.csv", "raw_path") is None

def test_raw_processor_missing_json():
    mock_spark = MagicMock()
    processor = RawProcessor(mock_spark)
    assert processor.landing_to_raw_json("invalid/path.json", "raw_path") is None