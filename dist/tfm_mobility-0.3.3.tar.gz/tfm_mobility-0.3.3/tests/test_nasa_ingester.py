import os
import pytest
from unittest.mock import patch
from tfm_mobility.ingesters.nasa_ingester import NASAIngester

@patch("tfm_mobility.utils.api_client.APIClient.get_text")
def test_nasa_ingester_landing_success(mock_get_text, tmp_path):
    # Mockear una respuesta válida en CSV
    fake_csv = "latitude,longitude,bright_ti4\n40.41,-3.70,320.5"
    mock_get_text.return_value = fake_csv

    # Instanciar el ingester apuntando a una carpeta temporal
    ingester = NASAIngester(base_landing_path=str(tmp_path))
    result_path = ingester.fetch_to_landing()

    assert result_path is not None
    assert os.path.exists(result_path)
    
    with open(result_path, "r", encoding="utf-8") as f:
        content = f.read()
    assert "latitude" in content