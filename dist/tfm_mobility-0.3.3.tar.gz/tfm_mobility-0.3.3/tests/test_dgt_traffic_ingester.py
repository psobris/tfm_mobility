import os
from unittest.mock import patch
from tfm_mobility.ingesters.realtime.dgt_traffic_ingester import DGTTrafficIngester

@patch("tfm_mobility.utils.api_client.APIClient.get_text")
def test_dgt_traffic_ingester_success(mock_get_text, tmp_path):
    fake_json = '{"incidencias": [{"carretera": "A-6", "causa": "ACCIDENTE", "estado": "CORTADO"}]}'
    mock_get_text.return_value = fake_json

    ingester = DGTTrafficIngester(base_landing_path=str(tmp_path))
    result_path = ingester.fetch_stream_to_landing()

    assert result_path is not None
    assert os.path.exists(result_path)
    
    with open(result_path, "r", encoding="utf-8") as f:
        content = f.read()
    assert "A-6" in content