import os
import json
from unittest.mock import patch, MagicMock
from tfm_mobility.ingesters.osm_ingester import OSMIngester

@patch("requests.post")
def test_osm_ingester_landing_success(mock_post, tmp_path):
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = {
        "elements": [{"id": 12345, "lat": 40.41, "lon": -3.70, "tags": {"amenity": "hospital"}}]
    }
    mock_post.return_value = mock_response

    ingester = OSMIngester(base_landing_path=str(tmp_path))
    result_path = ingester.fetch_hospitals_to_landing()

    assert result_path is not None
    assert os.path.exists(result_path)

    with open(result_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    assert "elements" in data