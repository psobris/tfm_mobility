import pytest
from unittest.mock import MagicMock, patch
from tfm_mobility.processors.raw_processor import RawProcessor

@pytest.fixture
def mock_spark():
    return MagicMock()

def test_raw_processor_landing_to_raw_csv(mock_spark):
    """Verifica la inyección de metadatos en la conversión CSV -> Parquet."""
    processor = RawProcessor(spark=mock_spark)
    
    mock_df = MagicMock()
    mock_df.count.return_value = 5
    mock_df.withColumn.return_value = mock_df
    
    mock_reader = MagicMock()
    mock_reader.option.return_value = mock_reader
    mock_reader.csv.return_value = mock_df
    mock_spark.read = mock_reader

    with patch("tfm_mobility.processors.raw_processor.F") as mock_f:
        mock_f.element_at.return_value = MagicMock()
        mock_f.split.return_value = MagicMock()
        mock_f.col.return_value = MagicMock()
        mock_f.current_timestamp.return_value = MagicMock()

        processor.landing_to_raw_csv("Files/landing/realtime/nasa_nrt", "Files/raw/realtime/nasa_nrt")

        assert mock_df.withColumn.call_count == 2
        mock_df.write.format.assert_called_once_with("parquet")

def test_raw_processor_landing_to_raw_json(mock_spark):
    """Verifica la inyección de metadatos en la conversión JSON -> Parquet."""
    processor = RawProcessor(spark=mock_spark)
    
    mock_df = MagicMock()
    mock_df.count.return_value = 3
    mock_df.withColumn.return_value = mock_df
    
    mock_reader = MagicMock()
    mock_reader.option.return_value = mock_reader
    mock_reader.json.return_value = mock_df
    mock_spark.read = mock_reader

    with patch("tfm_mobility.processors.raw_processor.F") as mock_f:
        mock_f.element_at.return_value = MagicMock()
        mock_f.split.return_value = MagicMock()
        mock_f.col.return_value = MagicMock()
        mock_f.current_timestamp.return_value = MagicMock()

        processor.landing_to_raw_json("Files/landing/realtime/weather", "Files/raw/realtime/weather")

        assert mock_df.withColumn.call_count == 2
        mock_df.write.format.assert_called_once_with("parquet")

def test_raw_processor_landing_to_raw_dgt_xml_no_files(mock_spark):
    """Verifica que el procesador DGT gestiona correctamente cuando no hay ficheros XML."""
    processor = RawProcessor(spark=mock_spark)
    with patch("os.path.exists", return_value=False):
        processor.landing_to_raw_dgt_xml("Files/landing/realtime/dgt_traffic", "Files/raw/realtime/dgt_traffic")
        mock_spark.createDataFrame.assert_not_called()