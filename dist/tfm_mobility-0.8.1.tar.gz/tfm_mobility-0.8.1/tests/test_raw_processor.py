from unittest.mock import MagicMock
from tfm_mobility.processors.raw_processor import RawProcessor

def test_raw_processor_sanitize_path():
    mock_spark = MagicMock()
    processor = RawProcessor(mock_spark)

    dirty_path = "/lakehouse/default/Files/landing/realtime/test.csv"
    clean_path = processor._sanitize_path(dirty_path)

    assert clean_path == "Files/landing/realtime/test.csv"

def test_raw_processor_is_batch_param():
    mock_spark = MagicMock()
    processor = RawProcessor(mock_spark)
    
    # Comprobar que no lanza error al pasar is_batch
    try:
        processor.landing_to_raw_csv("invalid_path.csv", "invalid_raw", is_batch=True)
        processor.landing_to_raw_json("invalid_path.json", "invalid_raw", is_batch=True)
    except Exception as e:
        assert False, f"Lanzó excepción insospechada: {e}"