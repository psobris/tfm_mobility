import json
from unittest.mock import patch, MagicMock
from tfm_mobility.ingesters.osm_ingester import OSMIngester

@patch("requests.post")
def test_osm_ingester_success(mock_post, tmp_path):
    fake_json = {"elements": [{"id": 123, "type": "way", "tags": {"highway": "motorway"}}]}
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = fake_json
    mock_post.return_value = mock_response

    ingester = OSMIngester()
    data = ingester.fetch_roads()

    assert data is not None
    assert "elements" in data
    assert len(data["elements"]) == 1

@patch("requests.post")
def test_osm_ingester_fetch_stream_to_landing(mock_post, tmp_path):
    fake_json = {"elements": [{"id": 456, "type": "way"}]}
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = fake_json
    mock_post.return_value = mock_response

    ingester = OSMIngester()
    landing_dir = str(tmp_path / "landing" / "batch" / "osm_roads")
    saved_path = ingester.fetch_stream_to_landing(landing_dir=landing_dir)

    assert saved_path is not None
    assert "osm_roads_" in saved_path