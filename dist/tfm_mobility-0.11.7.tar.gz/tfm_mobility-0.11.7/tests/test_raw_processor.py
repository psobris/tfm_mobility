import pytest
from unittest.mock import MagicMock, patch
from tfm_mobility.processors.raw_processor import RawProcessor

@pytest.fixture
def mock_spark():
    spark = MagicMock()
    return spark

def test_raw_processor_landing_to_raw_csv(mock_spark):
    """Verifica que el procesador RAW para CSV inyecte 'landing_source_file' e 'ingestion_timestamp'."""
    processor = RawProcessor(spark=mock_spark)
    
    mock_df = MagicMock()
    mock_df.count.return_value = 5
    mock_df.withColumn.return_value = mock_df
    
    mock_reader = MagicMock()
    mock_reader.option.return_value = mock_reader
    mock_reader.csv.return_value = mock_df
    mock_spark.read = mock_reader

    processor.landing_to_raw_csv("Files/landing/realtime/nasa_nrt", "Files/raw/realtime/nasa_nrt")

    # Comprobar que se añadió la columna de metadatos del archivo y la marca temporal
    assert mock_df.withColumn.call_count >= 2
    mock_df.write.format.assert_called_once_with("parquet")

def test_raw_processor_landing_to_raw_json(mock_spark):
    """Verifica que el procesador RAW para JSON inyecte los metadatos de trazabilidad."""
    processor = RawProcessor(spark=mock_spark)
    
    mock_df = MagicMock()
    mock_df.count.return_value = 3
    mock_df.withColumn.return_value = mock_df
    
    mock_reader = MagicMock()
    mock_reader.option.return_value = mock_reader
    mock_reader.json.return_value = mock_df
    mock_spark.read = mock_reader

    processor.landing_to_raw_json("Files/landing/realtime/weather", "Files/raw/realtime/weather")

    assert mock_df.withColumn.call_count >= 2
    mock_df.write.format.assert_called_once_with("parquet")