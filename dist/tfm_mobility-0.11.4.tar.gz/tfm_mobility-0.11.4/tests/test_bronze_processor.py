import pytest
from unittest.mock import MagicMock, patch
from tfm_mobility.processors.bronze_processor import BronzeProcessor

@pytest.fixture
def mock_spark():
    """Mock de la sesión de Spark para evitar arrancar PySpark/Java en Windows."""
    spark = MagicMock()
    spark.catalog.tableExists.return_value = True
    return spark

def test_bronze_processor_merge_into_bronze_exists(mock_spark):
    """Verifica que MERGE use la tabla Delta existente si ya está en el catálogo."""
    processor = BronzeProcessor(spark=mock_spark)
    
    mock_df = MagicMock()
    mock_df.rdd.isEmpty.return_value = False
    mock_df.dropDuplicates.return_value = mock_df
    mock_df.withColumn.return_value = mock_df

    mock_delta_table = MagicMock()
    
    with patch("tfm_mobility.processors.bronze_processor.DeltaTable") as mock_delta_class:
        mock_delta_class.forName.return_value = mock_delta_table
        mock_delta_table.alias.return_value = mock_delta_table
        mock_delta_table.merge.return_value = mock_delta_table
        mock_delta_table.whenNotMatchedInsertAll.return_value = mock_delta_table
        
        processor.merge_into_bronze(mock_df, "bronze_dgt_traffic", ["record_id"])

        # Comprobar que se llamó al MERGE de DeltaTable
        mock_delta_class.forName.assert_called_once_with(mock_spark, "bronze_dgt_traffic")
        mock_delta_table.merge.assert_called_once()
        mock_delta_table.execute.assert_called_once()

def test_bronze_processor_merge_into_bronze_new_table(mock_spark):
    """Verifica que se cree la tabla inicial si no existe en el catálogo."""
    mock_spark.catalog.tableExists.return_value = False
    processor = BronzeProcessor(spark=mock_spark)
    
    mock_df = MagicMock()
    mock_df.rdd.isEmpty.return_value = False
    mock_df.dropDuplicates.return_value = mock_df
    mock_df.withColumn.return_value = mock_df
    
    processor.merge_into_bronze(mock_df, "bronze_new_table", ["id"])
    
    # Debe intentar guardar como formato Delta por primera vez
    mock_df.write.format.assert_called_once_with("delta")