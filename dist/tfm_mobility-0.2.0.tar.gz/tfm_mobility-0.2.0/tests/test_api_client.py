import pytest
from tfm_mobility.utils.api_client import APIClient

def test_api_client_initialization():
    """Valida que el cliente se inicializa correctamente con sus cabeceras por defecto."""
    client = APIClient(base_url="https://api.example.com")
    assert client.base_url == "https://api.example.com"
    assert 'User-Agent' in client.headers

def test_api_client_real_request_success():
    """Prueba una petición GET real a una API pública ultraestable (JSONPlaceholder)."""
    client = APIClient()
    response = client.get("https://jsonplaceholder.typicode.com/posts/1")
    assert response is not None
    assert response.status_code == 200

def test_api_client_json_parsing():
    """Prueba que el método get_json devuelve un diccionario de Python correctamente."""
    client = APIClient()
    json_data = client.get_json("https://jsonplaceholder.typicode.com/posts/1")
    assert json_data is not None
    assert isinstance(json_data, dict)
    assert "userId" in json_data

def test_api_client_not_found():
    """Prueba cómo reacciona el cliente ante un error 404 (Not Found) devuelto por el servidor."""
    client = APIClient()
    response = client.get("https://jsonplaceholder.typicode.com/invalid_endpoint_404")
    assert response is None