import logging
import os
from typing import Optional
from pyspark.sql import SparkSession

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

class RawProcessor:
    """Procesador para convertir ficheros Landing (JSON/CSV) a Parquet estructurado en RAW."""

    def __init__(self, spark: SparkSession):
        self.spark = spark

    def _sanitize_path(self, path: str) -> str:
        """Saneador de rutas para eliminar prefijos absolutos de Fabric y normalizar slashes."""
        if not path:
            return ""
        clean = os.path.normpath(path).replace("\\", "/")
        prefix = "/lakehouse/default/"
        if clean.startswith(prefix):
            return clean[len(prefix):]
        if clean.startswith("lakehouse/default/"):
            return clean[len("lakehouse/default/")]
        return clean

    def landing_to_raw_csv(self, landing_path: str, raw_path: str) -> None:
        """Lee un archivo CSV de Landing y lo guarda como Parquet en RAW."""
        try:
            clean_landing = self._sanitize_path(landing_path)
            clean_raw = self._sanitize_path(raw_path)
            
            logging.info(f"📄 Leyendo CSV Landing: {clean_landing}")
            df = self.spark.read.option("header", "true").option("inferSchema", "true").csv(clean_landing)
            
            os.makedirs(clean_raw, exist_ok=True)
            df.write.format("parquet").mode("overwrite").save(clean_raw)
            logging.info(f"✅ Convertido a Parquet RAW en: {clean_raw}")
        except Exception as e:
            logging.error(f"❌ Error al convertir CSV a RAW ({landing_path}): {e}")

    def landing_to_raw_json(self, landing_path: str, raw_path: str) -> None:
        """Lee un archivo JSON de Landing y lo guarda como Parquet en RAW."""
        try:
            clean_landing = self._sanitize_path(landing_path)
            clean_raw = self._sanitize_path(raw_path)
            
            logging.info(f"📄 Leyendo JSON Landing: {clean_landing}")
            df = self.spark.read.option("multiline", "true").json(clean_landing)
            
            os.makedirs(clean_raw, exist_ok=True)
            df.write.format("parquet").mode("overwrite").save(clean_raw)
            logging.info(f"✅ Convertido a Parquet RAW en: {clean_raw}")
        except Exception as e:
            logging.error(f"❌ Error al convertir JSON a RAW ({landing_path}): {e}")

    def process_realtime_sources(self) -> None:
        """Procesa todas las fuentes de tiempo real presentes en Landing."""
        base_landing = "/lakehouse/default/Files/landing/realtime"
        base_raw = "/lakehouse/default/Files/raw/realtime"

        # 1. Weather (JSON)
        weather_landing = self._sanitize_path(os.path.join(base_landing, "weather"))
        if os.path.exists(weather_landing):
            files = [os.path.join(weather_landing, f) for f in os.listdir(weather_landing) if f.endswith(".json")]
            if files:
                latest_file = sorted(files)[-1]
                self.landing_to_raw_json(latest_file, os.path.join(base_raw, "weather"))

        # 2. NASA NRT (CSV)
        nasa_landing = self._sanitize_path(os.path.join(base_landing, "nasa_nrt"))
        if os.path.exists(nasa_landing):
            csv_files = []
            for root, _, files in os.walk(nasa_landing):
                for f in files:
                    if f.endswith(".csv"):
                        csv_files.append(os.path.join(root, f))
            if csv_files:
                latest_csv = sorted(csv_files)[-1]
                self.landing_to_raw_csv(latest_csv, os.path.join(base_raw, "nasa_nrt"))

        # 3. DGT Traffic (JSON)
        dgt_landing = self._sanitize_path(os.path.join(base_landing, "dgt_traffic"))
        if os.path.exists(dgt_landing):
            files = [os.path.join(dgt_landing, f) for f in os.listdir(dgt_landing) if f.endswith(".json")]
            if files:
                latest_file = sorted(files)[-1]
                self.landing_to_raw_json(latest_file, os.path.join(base_raw, "dgt_traffic"))