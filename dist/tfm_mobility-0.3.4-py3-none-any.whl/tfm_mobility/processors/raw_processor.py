import os
import logging
from pyspark.sql import SparkSession

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

class RawProcessor:
    """Procesador para la transición 3. LANDING -> 4. RAW (Conversión a Parquet incremental)."""

    def __init__(self, spark: SparkSession):
        self.spark = spark

    def _format_spark_path(self, path: str) -> str:
        """Asegura que la ruta sea accesible por el driver de PySpark en Fabric."""
        if not path.startswith("/lakehouse/default/"):
            clean_path = path.lstrip("/")
            if not clean_path.startswith("Files/"):
                clean_path = f"Files/{clean_path}"
            return f"/lakehouse/default/{clean_path}"
        return path

    def landing_to_raw_csv(self, landing_file_path: str, raw_base_path: str) -> str:
        if not landing_file_path or not os.path.exists(landing_file_path):
            logging.error(f"❌ Archivo de Landing no encontrado: {landing_file_path}")
            return None

        spark_landing_path = self._format_spark_path(landing_file_path)
        logging.info(f"⚙️ [RAW] Moviendo CSV de LANDING a RAW: {spark_landing_path}")

        file_name = os.path.basename(landing_file_path).replace(".csv", ".parquet")
        parent_dir = os.path.dirname(landing_file_path)

        target_dir = self._format_spark_path(os.path.join(raw_base_path, os.path.basename(parent_dir)))
        os.makedirs(target_dir, exist_ok=True)
        target_path = os.path.join(target_dir, file_name)

        df = self.spark.read.option("header", "true").option("inferSchema", "true").csv(spark_landing_path)
        df.write.mode("overwrite").parquet(target_path)

        logging.info(f"💾 [RAW OK] Archivo Parquet guardado en: {target_path}")
        return target_path

    def landing_to_raw_json(self, landing_file_path: str, raw_base_path: str) -> str:
        if not landing_file_path or not os.path.exists(landing_file_path):
            logging.error(f"❌ Archivo de Landing no encontrado: {landing_file_path}")
            return None

        spark_landing_path = self._format_spark_path(landing_file_path)
        logging.info(f"⚙️ [RAW] Moviendo JSON de LANDING a RAW: {spark_landing_path}")

        file_name = os.path.basename(landing_file_path).replace(".json", ".parquet")
        parent_dir = os.path.dirname(landing_file_path)

        target_dir = self._format_spark_path(os.path.join(raw_base_path, os.path.basename(parent_dir)))
        os.makedirs(target_dir, exist_ok=True)
        target_path = os.path.join(target_dir, file_name)

        df = self.spark.read.option("multiline", "true").json(spark_landing_path)
        df.write.mode("overwrite").parquet(target_path)

        logging.info(f"💾 [RAW OK] Archivo Parquet guardado en: {target_path}")
        return target_path