import os
import logging
import requests
from datetime import datetime

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

class DGTTrafficIngester:
    """Ingester NRT (cada 5 min) para infraestructura de tráfico e incidencias viales en Madrid (Overpass API)."""

    def __init__(self, base_landing_path: str = "/lakehouse/default/Files/landing/realtime/dgt_traffic"):
        self.base_landing_path = base_landing_path
        self.traffic_url = "https://overpass-api.de/api/interpreter"
        # Consulta espacial para nodos de tráfico y vías en Madrid (con lat/lon)
        self.query = "[out:json][timeout:25];(node['highway'](40.3,-3.8,40.5,-3.5););out body 100;"
        self.headers = {
            "User-Agent": "TFM_Mobility_App/1.0 (contact: pasobrad@ucm.es)"
        }

    def fetch_stream_to_landing(self) -> str:
        logging.info("⚡ [REAL-TIME] Consultando API espacial de tráfico y red vial (Madrid)...")
        
        try:
            response = requests.post(
                self.traffic_url, 
                data={"data": self.query}, 
                headers=self.headers, 
                timeout=15
            )
            
            if response.status_code != 200:
                logging.error(f"❌ Error al consultar API de tráfico: HTTP {response.status_code}")
                return None
                
            raw_data = response.text
            
        except Exception as e:
            logging.error(f"❌ Excepción en la ingesta de tráfico: {e}")
            return None

        now = datetime.now()
        year_str = now.strftime("%Y")
        month_str = now.strftime("%m")
        day_str = now.strftime("%d")
        hour_str = now.strftime("%H")

        dir_dest = os.path.join(self.base_landing_path, year_str, month_str, day_str, hour_str)
        os.makedirs(dir_dest, exist_ok=True)

        timestamp_str = now.strftime("%Y%m%d_%H%M%S")
        file_name = f"dgt_traffic_{timestamp_str}.json"
        file_path = os.path.join(dir_dest, file_name)

        with open(file_path, "w", encoding="utf-8") as f:
            f.write(raw_data)

        logging.info(f"📥 [LANDING OK] JSON geolocalizado guardado en: {file_path}")
        return file_path