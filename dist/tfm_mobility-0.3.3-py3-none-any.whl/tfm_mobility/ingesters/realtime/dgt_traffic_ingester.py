import os
import logging
from datetime import datetime
from tfm_mobility.utils.api_client import APIClient

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

class DGTTrafficIngester:
    """Ingester de alta frecuencia (cada 5 min) para tráfico e incidencias DGT."""

    def __init__(self, base_landing_path: str = "Files/landing/realtime/dgt_traffic"):
        self.client = APIClient()
        self.base_landing_path = base_landing_path
        self.traffic_url = "https://nap.dgt.es/api/v1/incidencias"

    def fetch_stream_to_landing(self) -> str:
        logging.info("⚡ [REAL-TIME] Consultando incidencias de tráfico DGT...")
        raw_data = self.client.get_text(self.traffic_url)

        if not raw_data:
            logging.warning("⚠️ No se pudo obtener respuesta del feed de la DGT.")
            return None

        now = datetime.now()
        year_str = now.strftime("%Y")
        month_str = now.strftime("%m")
        day_str = now.strftime("%d")
        hour_str = now.strftime("%H")

        dir_dest = os.path.join(self.base_landing_path, year_str, month_str, day_str, hour_str)
        os.makedirs(dir_dest, exist_ok=True)

        timestamp_str = now.strftime("%Y%m%d_%H%M%S")
        file_name = f"dgt_traffic_{timestamp_str}.json"
        file_path = os.path.join(dir_dest, file_name)

        with open(file_path, "w", encoding="utf-8") as f:
            f.write(raw_data)

        logging.info(f"📥 [LANDING OK] Incidencias de tráfico guardadas en: {file_path}")
        return file_path