import os
import logging
from datetime import datetime
from tfm_mobility.utils.api_client import APIClient

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

class WeatherIngester:
    """Ingester de alta frecuencia (cada 5 min) para meteorología y viento."""

    def __init__(self, base_landing_path: str = "Files/landing/realtime/weather"):
        self.client = APIClient()
        self.base_landing_path = base_landing_path
        self.api_url = "https://api.open-meteo.com/v1/forecast?latitude=40.4168&longitude=-3.7038&current=temperature_2m,relative_humidity_2m,wind_speed_10m,wind_direction_10m,wind_gusts_10m"

    def fetch_to_landing(self) -> str:
        logging.info("⚡ [REAL-TIME] Consultando datos meteorológicos en vivo...")
        data = self.client.get_text(self.api_url)

        if not data:
            logging.error("❌ Fallo al consultar API meteorológica.")
            return None

        now = datetime.now()
        year_str = now.strftime("%Y")
        month_str = now.strftime("%m")
        day_str = now.strftime("%d")
        hour_str = now.strftime("%H")

        dir_dest = os.path.join(self.base_landing_path, year_str, month_str, day_str, hour_str)
        os.makedirs(dir_dest, exist_ok=True)

        timestamp_str = now.strftime("%Y%m%d_%H%M%S")
        file_name = f"weather_{timestamp_str}.json"
        file_path = os.path.join(dir_dest, file_name)

        with open(file_path, "w", encoding="utf-8") as f:
            f.write(data)

        logging.info(f"📥 [LANDING OK] Datos meteorológicos guardados en: {file_path}")
        return file_path