import requests
import logging
from typing import Dict, Any, Optional

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

class APIClient:
    """
    Clase cliente modular para realizar peticiones HTTP a APIs REST o archivos públicos de forma segura.
    Incluye manejo de cabeceras, tiempos de espera (timeouts) y captura de errores de red.
    """
    def __init__(self, base_url: str = "", default_headers: Optional[Dict[str, str]] = None):
        """
        Inicializa el cliente con una URL base opcional y cabeceras por defecto.
        """
        self.base_url = base_url
        # 💡 Cambiamos a un User-Agent de navegador para evitar bloqueos HTTP 403 (como el de la DGT)
        self.headers = default_headers or {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': '*/*'
        }

    def get(self, endpoint: str = "", params: Optional[Dict[str, Any]] = None, timeout: int = 15) -> Optional[requests.Response]:
        """
        Realiza una petición HTTP GET.
        """
        url = f"{self.base_url}{endpoint}" if self.base_url else endpoint
        logging.info(f"Iniciando petición GET a: {url}")

        try:
            response = requests.get(url, headers=self.headers, params=params, timeout=timeout)
            response.raise_for_status()
            logging.info(f"Petición exitosa [{response.status_code}] desde: {url}")
            return response

        except requests.exceptions.HTTPError as http_err:
            status_code = response.status_code if 'response' in locals() and response is not None else "Desconocido"
            logging.error(f"Error HTTP [{status_code}] en {url}: {http_err}")
        except requests.exceptions.Timeout:
            logging.error(f"Tiempo de espera agotado ({timeout}s) al conectar con {url}")
        except requests.exceptions.RequestException as req_err:
            logging.error(f"Fallo de conexión en {url}: {req_err}")
        
        return None

    def get_json(self, endpoint: str = "", params: Optional[Dict[str, Any]] = None) -> Optional[Dict[str, Any]]:
        """
        Realiza una petición GET y devuelve la respuesta parseada como un diccionario JSON.
        """
        response = self.get(endpoint=endpoint, params=params)
        if response:
            try:
                return response.json()
            except Exception as e:
                logging.error(f"Error al decodificar la respuesta JSON: {e}")
        return None

    def get_text(self, endpoint: str = "", params: Optional[Dict[str, Any]] = None) -> Optional[str]:
        """
        Realiza una petición GET y devuelve la respuesta como texto plano (útil para CSVs como NASA FIRMS).
        """
        response = self.get(endpoint=endpoint, params=params)
        if response:
            return response.text
        return None