import os
import logging
from pyspark.sql import SparkSession

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

class RawProcessor:
    """Procesador para la transición 3. LANDING -> 4. RAW (Conversión a Parquet incremental)."""

    def __init__(self, spark: SparkSession):
        self.spark = spark

    def landing_to_raw_csv(self, landing_file_path: str, raw_base_path: str) -> str:
        """Convierte un CSV de Landing a Parquet en RAW preservando la ruta de partición."""
        if not landing_file_path or not os.path.exists(landing_file_path):
            logging.error(f"❌ Archivo de Landing no encontrado: {landing_file_path}")
            return None

        logging.info(f"⚙️ [RAW] Moviendo CSV de LANDING a RAW: {landing_file_path}")

        file_name = os.path.basename(landing_file_path).replace(".csv", ".parquet")
        
        # Obtiene la subcarpeta relativa (ej: realtime/nasa_nrt/2026/08/04/09)
        parent_dir = os.path.dirname(landing_file_path)
        
        target_dir = os.path.join(raw_base_path, os.path.basename(parent_dir))
        os.makedirs(target_dir, exist_ok=True)
        target_path = os.path.join(target_dir, file_name)

        df = self.spark.read.option("header", "true").option("inferSchema", "true").csv(landing_file_path)
        df.write.mode("overwrite").parquet(target_path)

        logging.info(f"💾 [RAW OK] Archivo Parquet guardado en: {target_path}")
        return target_path

    def landing_to_raw_json(self, landing_file_path: str, raw_base_path: str) -> str:
        """Convierte un JSON de Landing a Parquet en RAW preservando la ruta de partición."""
        if not landing_file_path or not os.path.exists(landing_file_path):
            logging.error(f"❌ Archivo de Landing no encontrado: {landing_file_path}")
            return None

        logging.info(f"⚙️ [RAW] Moviendo JSON de LANDING a RAW: {landing_file_path}")

        file_name = os.path.basename(landing_file_path).replace(".json", ".parquet")
        parent_dir = os.path.dirname(landing_file_path)

        target_dir = os.path.join(raw_base_path, os.path.basename(parent_dir))
        os.makedirs(target_dir, exist_ok=True)
        target_path = os.path.join(target_dir, file_name)

        df = self.spark.read.option("multiline", "true").json(landing_file_path)
        df.write.mode("overwrite").parquet(target_path)

        logging.info(f"💾 [RAW OK] Archivo Parquet guardado en: {target_path}")
        return target_path