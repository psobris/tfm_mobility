import logging
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import DoubleType, StringType, IntegerType

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

class BronzeProcessor:
    """Procesador para la transición 4. RAW -> 5. BRONZE (Tablas Delta Estandarizadas)."""

    def __init__(self, spark: SparkSession):
        self.spark = spark

    def raw_to_bronze_nasa(self, raw_parquet_path: str, bronze_delta_path: str):
        """Estandariza los datos de incendios de NASA FIRMS en Bronze."""
        logging.info(f"⚙️ [BRONZE] Estandarizando NASA FIRMS -> {bronze_delta_path}")
        df_raw = self.spark.read.parquet(raw_parquet_path)

        df_bronze = df_raw \
            .withColumn("latitude", F.col("latitude").cast(DoubleType())) \
            .withColumn("longitude", F.col("longitude").cast(DoubleType())) \
            .withColumn("bright_ti4", F.col("bright_ti4").cast(DoubleType())) \
            .withColumn("frp", F.col("frp").cast(DoubleType())) \
            .withColumn("ingestion_timestamp", F.current_timestamp())

        df_bronze.write.format("delta").mode("append").save(bronze_delta_path)
        return df_bronze

    def raw_to_bronze_weather(self, raw_parquet_path: str, bronze_delta_path: str):
        """Estandariza las mediciones climáticas en Bronze."""
        logging.info(f"⚙️ [BRONZE] Estandarizando Clima -> {bronze_delta_path}")
        df_raw = self.spark.read.parquet(raw_parquet_path)

        df_bronze = df_raw \
            .withColumn("ingestion_timestamp", F.current_timestamp())

        df_bronze.write.format("delta").mode("append").save(bronze_delta_path)
        return df_bronze

    def raw_to_bronze_dgt(self, raw_parquet_path: str, bronze_delta_path: str):
        """Estandariza las incidencias de tráfico de la DGT en Bronze."""
        logging.info(f"⚙️ [BRONZE] Estandarizando Tráfico DGT -> {bronze_delta_path}")
        df_raw = self.spark.read.parquet(raw_parquet_path)

        df_bronze = df_raw \
            .withColumn("ingestion_timestamp", F.current_timestamp())

        df_bronze.write.format("delta").mode("append").save(bronze_delta_path)
        return df_bronze