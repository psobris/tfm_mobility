import logging
from pyspark.sql import SparkSession
from pyspark.sql import functions as F

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

class SilverProcessor:
    """Procesador PySpark para enriquecimiento y filtrado espacial en la Capa 6. SILVER."""

    def __init__(self, spark: SparkSession):
        self.spark = spark

    def process_emergencies_silver(self, bronze_nasa_path: str, bronze_weather_path: str, silver_delta_path: str):
        """
        Lee los datos limpios de Bronze (NASA FIRMS y Clima), los acopla territorialmente 
        para la Comunidad de Madrid y evalúa el nivel de amenaza integrado.
        """
        logging.info("⚙️ [SILVER] Procesando integración espacial Fuego + Clima...")

        df_nasa = self.spark.read.format("delta").load(bronze_nasa_path)
        df_weather = self.spark.read.format("delta").load(bronze_weather_path)

        # Bounding Box geográfico de la Comunidad de Madrid
        # Latitud: 39.88 a 41.16 | Longitud: -4.58 a -3.05
        df_madrid_fires = df_nasa \
            .filter((F.col("latitude") >= 39.88) & (F.col("latitude") <= 41.16)) \
            .filter((F.col("longitude") >= -4.58) & (F.col("longitude") <= -3.05))

        # Clasificación del nivel de riesgo térmico
        df_enriched_fires = df_madrid_fires \
            .withColumn("nivel_riesgo_fuego",
                F.when(F.col("bright_ti4") > 340, "CRÍTICO")
                 .when(F.col("bright_ti4") > 320, "ALTO")
                 .otherwise("MODERADO")
            )

        # Cruce o unión de contexto meteorológico (ej. viento en ese instante)
        # Para simplificar el cálculo distribuido se asocia el timestamp de ingesta
        df_silver = df_enriched_fires \
            .withColumn("processed_timestamp", F.current_timestamp())

        # Guardar en la tabla Delta de Silver (Modo overwrite para mantener el estado consolidado activo)
        df_silver.write.format("delta").mode("overwrite").save(silver_delta_path)
        
        logging.info(f"🥈 [SILVER OK] Tabla Delta integrada guardada en: {silver_delta_path}")
        return df_silver