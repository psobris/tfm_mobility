import os
import json
import logging
from datetime import datetime
from pyspark.sql import SparkSession

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

class RawProcessor:
    """Procesador para promocionar archivos de Landing a formato Parquet en RAW."""

    def __init__(self, spark: SparkSession):
        self.spark = spark

    def _sanitize_path(self, path: str) -> str:
        if not path:
            return ""
        return path.replace("/lakehouse/default/", "").replace("\\", "/")

    # --- TUS OTROS MÉTODOS (landing_to_raw_csv, landing_to_raw_json, landing_to_raw_dgt_xml, etc.) ---

    def landing_to_raw_osm(self, landing_path: str):
        clean_path = self._sanitize_path(landing_path)
        local_file_path = os.path.join("/lakehouse/default", clean_path)
        
        logging.info(f"⚙️ [RAW] Parseando datos de OSM desde {local_file_path}...")
        with open(local_file_path, "r", encoding="utf-8") as f:
            osm_data = json.load(f)

        elements = osm_data.get("elements", [])
        
        road_rows = []
        place_rows = []

        for el in elements:
            tags = el.get("tags", {})
            
            # 1. Parsear Vías / Carreteras
            if "highway" in tags:
                road_rows.append({
                    "id": el.get("id"),
                    "type": el.get("type"),
                    "highway": tags.get("highway"),
                    "name": tags.get("name"),
                    "ref": tags.get("ref"),
                    "maxspeed": tags.get("maxspeed"),
                    "lanes": tags.get("lanes"),
                    "nodes_count": len(el.get("nodes", []))
                })
            
            # 2. Parsear Poblaciones y Zonas Residenciales
            if "place" in tags or tags.get("landuse") == "residential":
                place_rows.append({
                    "id": el.get("id"),
                    "type": el.get("type"),
                    "name": tags.get("name", "Zona Residencial Sin Nombre"),
                    "place_type": tags.get("place", tags.get("landuse")),
                    "population": tags.get("population"),
                    "latitude": el.get("lat"),
                    "longitude": el.get("lon")
                })

        # Guardar Carreteras en Parquet
        if road_rows:
            df_roads = self.spark.createDataFrame(road_rows)
            target_roads = "Files/raw/batch/osm_networks"
            df_roads.write.mode("overwrite").parquet(target_roads)
            logging.info(f"✅ [RAW OK] OSM Carreteras guardadas en {target_roads} ({df_roads.count()} tramos)")

        # Guardar Poblaciones en Parquet
        if place_rows:
            df_places = self.spark.createDataFrame(place_rows)
            target_places = "Files/raw/batch/osm_places"
            df_places.write.mode("overwrite").parquet(target_places)
            logging.info(f"✅ [RAW OK] OSM Poblaciones guardadas en {target_places} ({df_places.count()} núcleos)")