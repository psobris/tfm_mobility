import logging
import os
from pyspark.sql import SparkSession

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

class BronzeProcessor:
    """Procesador para promocionar archivos Parquet de RAW a Tablas Delta en Bronze."""

    def __init__(self, spark: SparkSession):
        self.spark = spark

    def _get_abfs_path(self, relative_path: str) -> str:
        """Construye la ruta ABFS nativa directa usando la configuración del Lakehouse activo."""
        clean_path = relative_path.replace("/lakehouse/default/", "").strip("/")
        if clean_path.startswith("Files/"):
            clean_path = clean_path[6:]
        
        # Obtiene la ruta base abfss:// del Lakehouse predeterminado
        try:
            default_fs = self.spark.conf.get("spark.hadoop.fs.defaultFS")
            if default_fs and default_fs.startswith("abfss://"):
                return f"{default_fs}/Files/{clean_path}"
        except Exception:
            pass
        
        # Fallback de ruta ABFS estándar de Fabric
        return f"Files/{clean_path}"

    def raw_to_bronze_table(self, raw_parquet_path: str, table_name: str, mode: str = "overwrite"):
        """Convierte una carpeta Parquet de RAW a una Tabla Delta en la sección Tables de Fabric."""
        try:
            clean_path = raw_parquet_path.replace("/lakehouse/default/", "").strip("/")
            if not clean_path.startswith("Files/"):
                clean_path = f"Files/{clean_path}"
                
            fs_local_path = f"/lakehouse/default/{clean_path}"
            
            # 1. Comprobación de existencia en el sistema de archivos local FUSE
            if not os.path.exists(fs_local_path):
                logging.warning(f"⚠️ [BRONZE OMITIDO] La ruta local {fs_local_path} no existe en disco.")
                return False

            # 2. Construir ruta ABFS limpia
            abfs_target = self._get_abfs_path(clean_path)
            logging.info(f"⚙️ [BRONZE] Leyendo Parquet vía ABFS desde {abfs_target}...")
            
            # Usamos option option('recursiveFileLookup', 'true') para leer todas las subparticiones sin error HEAD
            df = self.spark.read.option("recursiveFileLookup", "true").parquet(abfs_target)
            
            if df.rdd.isEmpty():
                logging.warning(f"⚠️ [BRONZE OMITIDO] El dataset en {abfs_target} no contiene registros.")
                return False

            total_records = df.count()
            logging.info(f"⚙️ [BRONZE] Guardando {total_records} registros en la Tabla Delta '{table_name}'...")
            
            # Guardado directo en la sección Tables sin prefijo default.
            df.write.format("delta") \
                .mode(mode) \
                .option("overwriteSchema", "true") \
                .saveAsTable(table_name)
            
            logging.info(f"✅ [BRONZE OK] Tabla Delta '{table_name}' creada/actualizada con éxito.")
            return True
            
        except Exception as e:
            logging.error(f"❌ Error al crear la tabla Bronze '{table_name}': {e}")
            return False

    def promote_realtime_to_bronze(self):
        """Procesa exclusivamente las fuentes NRT/Real-Time a Bronze (cada 10-15 min)."""
        datasets = [
            ("Files/raw/realtime/nasa_nrt", "bronze_nasa_nrt"),
            ("Files/raw/realtime/weather", "bronze_weather"),
            ("Files/raw/realtime/dgt_traffic", "bronze_dgt_traffic")
        ]
        logging.info("🚀 [BRONZE NRT] Promocionando fuentes Real-Time a Tablas Delta...")
        for raw_path, table_name in datasets:
            self.raw_to_bronze_table(raw_path, table_name)

    def promote_batch_to_bronze(self):
        """Procesa exclusivamente las fuentes pesadas/estáticas a Bronze (diario)."""
        datasets = [
            ("Files/raw/batch/nasa_historical", "bronze_nasa_historical"),
            ("Files/raw/batch/osm_networks", "bronze_osm_roads"),
            ("Files/raw/batch/osm_places", "bronze_osm_places")
        ]
        logging.info("📦 [BRONZE BATCH] Promocionando fuentes Batch a Tablas Delta...")
        for raw_path, table_name in datasets:
            self.raw_to_bronze_table(raw_path, table_name)

    def promote_all_raw_to_bronze(self):
        """Orquestador global legacy."""
        self.promote_realtime_to_bronze()
        self.promote_batch_to_bronze()