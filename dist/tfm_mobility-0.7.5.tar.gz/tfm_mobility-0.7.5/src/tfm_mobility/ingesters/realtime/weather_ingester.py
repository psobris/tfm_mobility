import logging
import os
from datetime import datetime
import requests
import pandas as pd
from typing import Optional

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

class WeatherIngestor:
    """Ingestor para la API de Open-Meteo (Tiempo actual y pronóstico futuro a 7 días)."""

    BASE_URL = "https://api.open-meteo.com/v1/forecast"

    def __init__(self, latitude: float = 40.4168, longitude: float = -3.7038):
        self.latitude = latitude
        self.longitude = longitude

    def fetch_forecast(self, forecast_days: int = 7) -> Optional[pd.DataFrame]:
        """Obtiene la predicción meteorológica hora a hora para los próximos N días."""
        params = {
            "latitude": self.latitude,
            "longitude": self.longitude,
            "hourly": "temperature_2m,relative_humidity_2m,precipitation_probability,precipitation,rain,showers,snowfall,wind_speed_10m,wind_gusts_10m",
            "forecast_days": forecast_days,
            "timezone": "Europe/Madrid"
        }
        
        try:
            logging.info(f"🌤️ [WEATHER] Solicitando pronóstico a {forecast_days} días para ({self.latitude}, {self.longitude})...")
            response = requests.get(self.BASE_URL, params=params, timeout=15)
            response.raise_for_status()
            
            data = response.json()
            hourly_data = data.get("hourly", {})
            
            if not hourly_data:
                logging.warning("⚠️ [WEATHER] La respuesta no contiene datos horarios.")
                return None

            df = pd.DataFrame(hourly_data)
            df["latitude"] = self.latitude
            df["longitude"] = self.longitude
            df["elevation"] = data.get("elevation", 0)
            df["timezone"] = data.get("timezone", "Europe/Madrid")
            
            logging.info(f"✅ [WEATHER OK] Se han obtenido {len(df)} registros horarios de predicción.")
            return df

        except Exception as e:
            logging.error(f"❌ [WEATHER ERROR] Fallo al consultar Open-Meteo: {e}")
            return None

    def fetch_stream_to_landing(self, landing_dir: str = "/lakehouse/default/Files/landing/realtime/weather") -> Optional[str]:
        """Método de compatibilidad con notebooks 01_landing. Guarda el JSON/CSV en landing."""
        df = self.fetch_forecast()
        if df is None or df.empty:
            return None
            
        os.makedirs(landing_dir, exist_ok=True)
        timestamp_str = datetime.now().strftime("%Y%m%d_%H%M%S")
        file_path = os.path.join(landing_dir, f"weather_{timestamp_str}.json")
        
        df.to_json(file_path, orient="records", date_format="iso")
        logging.info(f"💾 [WEATHER LANDING] Archivo guardado en: {file_path}")
        return file_path