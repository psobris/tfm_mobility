import os
import logging
from datetime import datetime
from tfm_mobility.utils.api_client import APIClient

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

class OSMIngester:
    """Ingestador para descargar red viaria y poblaciones de OpenStreetMap (Overpass API)."""

    OVERPASS_URL = "https://overpass-api.de/api/interpreter"

    def __init__(self, base_landing_path: str = "/lakehouse/default/Files/landing/batch/osm_data"):
        self.base_landing_path = base_landing_path
        self.api_client = APIClient()

    def _build_overpass_query(self) -> str:
        """
        Consulta QL optimizada para Madrid.
        Bounding Box Madrid: S=40.0, W=-4.5, N=41.2, E=-3.1
        """
        return """
        [out:json][timeout:90];
        (
          way["highway"~"motorway|trunk|primary|secondary|tertiary"](40.0,-4.5,41.2,-3.1);
          node["place"~"city|town|village"](40.0,-4.5,41.2,-3.1);
        );
        out body;
        >;
        out skel qt;
        """

    def fetch_batch_to_landing(self) -> str:
        logging.info("📦 [BATCH] Consultando infraestructura vial y poblaciones en OpenStreetMap...")
        query = self._build_overpass_query()
        
        # Encabezados requeridos por Overpass API para evitar el error 406
        headers = {
            "User-Agent": "TFMMobilityApp/1.0 (Contact: paula.sobrados@example.com)",
            "Content-Type": "application/x-www-form-urlencoded"
        }
        
        # Petición POST enviando query como data
        response = self.api_client.post(
            self.OVERPASS_URL, 
            data={"data": query}, 
            headers=headers
        )
        
        if response and response.status_code == 200:
            now = datetime.now()
            folder_path = os.path.join(
                self.base_landing_path,
                now.strftime("%Y"),
                now.strftime("%m"),
                now.strftime("%d")
            )
            os.makedirs(folder_path, exist_ok=True)
            
            filename = f"osm_data_{now.strftime('%Y%m%d_%H%M%S')}.json"
            full_path = os.path.join(folder_path, filename)
            
            with open(full_path, "w", encoding="utf-8") as f:
                f.write(response.text)
                
            clean_path = full_path.replace("/lakehouse/default/", "").replace("\\", "/")
            logging.info(f"✅ [BATCH OK] Datos de OSM guardados en: {clean_path}")
            return clean_path
        else:
            status = response.status_code if response else "Sin respuesta"
            logging.error(f"❌ Error HTTP {status} al consultar OSM.")
            return None