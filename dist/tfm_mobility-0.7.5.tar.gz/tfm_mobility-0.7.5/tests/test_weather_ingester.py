from unittest.mock import patch, MagicMock
from tfm_mobility.ingesters.realtime.weather_ingester import WeatherIngestor

@patch("requests.get")
def test_fetch_forecast_success(mock_get):
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = {
        "elevation": 667,
        "timezone": "Europe/Madrid",
        "hourly": {
            "time": ["2026-08-06T00:00", "2026-08-06T01:00"],
            "temperature_2m": [22.5, 21.8],
            "precipitation_probability": [0, 5],
            "precipitation": [0.0, 0.0],
            "wind_speed_10m": [12.1, 10.5]
        }
    }
    mock_get.return_value = mock_response

    ingestor = WeatherIngestor()
    df = ingestor.fetch_forecast(forecast_days=7)

    assert df is not None
    assert len(df) == 2
    assert "temperature_2m" in df.columns
    assert df["latitude"].iloc[0] == 40.4168