from unittest.mock import MagicMock
from tfm_mobility.processors.silver_processor import SilverProcessor

def test_silver_processor_init():
    mock_spark = MagicMock()
    processor = SilverProcessor(mock_spark)
    assert processor.spark == mock_spark