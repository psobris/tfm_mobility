from unittest.mock import MagicMock
from tfm_mobility.processors.raw_processor import RawProcessor

def test_raw_processor_sanitize_path():
    mock_spark = MagicMock()
    processor = RawProcessor(mock_spark)
    
    dirty_path = "/lakehouse/default/Files/landing/realtime/test.csv"
    clean_path = processor._sanitize_path(dirty_path)
    
    assert clean_path == "Files/landing/realtime/test.csv"