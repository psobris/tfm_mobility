from unittest.mock import MagicMock, patch
from tfm_mobility.processors.bronze_processor import BronzeProcessor

@patch("os.path.exists", return_value=True)
def test_raw_to_bronze_table_success(mock_exists):
    mock_spark = MagicMock()
    mock_df = MagicMock()
    mock_reader = MagicMock()
    
    mock_spark.conf.get.return_value = "abfss://workspace@onelake.dfs.fabric.microsoft.com/lakehouse"
    mock_spark.read.option.return_value = mock_reader
    mock_reader.parquet.return_value = mock_df
    
    mock_df.rdd.isEmpty.return_value = False
    mock_df.count.return_value = 100
    
    mock_writer = MagicMock()
    mock_df.write.format.return_value = mock_writer
    mock_writer.mode.return_value = mock_writer
    mock_writer.option.return_value = mock_writer
    
    processor = BronzeProcessor(mock_spark)
    result = processor.raw_to_bronze_table("Files/raw/realtime/nasa_nrt", "bronze_nasa_nrt")
    
    assert result is True
    mock_writer.saveAsTable.assert_called_once_with("bronze_nasa_nrt")

@patch.object(BronzeProcessor, 'raw_to_bronze_table')
def test_promote_realtime_to_bronze(mock_raw_to_bronze):
    mock_spark = MagicMock()
    processor = BronzeProcessor(mock_spark)
    processor.promote_realtime_to_bronze()
    assert mock_raw_to_bronze.call_count == 3

@patch.object(BronzeProcessor, 'raw_to_bronze_table')
def test_promote_batch_to_bronze(mock_raw_to_bronze):
    mock_spark = MagicMock()
    processor = BronzeProcessor(mock_spark)
    processor.promote_batch_to_bronze()
    assert mock_raw_to_bronze.call_count == 3