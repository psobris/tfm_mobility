import os
from unittest.mock import patch, MagicMock
from tfm_mobility.ingesters.osm_ingester import OSMIngester

@patch("requests.post")
def test_osm_ingester_success(mock_post, tmp_path):
    fake_json = '{"elements": [{"id": 123, "type": "way", "tags": {"highway": "motorway"}}]}'
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.text = fake_json
    mock_post.return_value = mock_response

    ingester = OSMIngester(base_landing_path=str(tmp_path))
    result_path = ingester.fetch_batch_to_landing()

    assert result_path is not None
    assert "osm_data_" in result_path