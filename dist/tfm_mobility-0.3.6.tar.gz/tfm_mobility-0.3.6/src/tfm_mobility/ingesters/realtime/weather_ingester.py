import os
import logging
import requests
from datetime import datetime

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

class WeatherIngester:
    """Ingester NRT para datos meteorológicos en tiempo real desde Open-Meteo."""

    def __init__(self, base_landing_path: str = "Files/landing/realtime/weather"):
        self.base_landing_path = base_landing_path
        self.weather_url = (
            "https://api.open-meteo.com/v1/forecast?"
            "latitude=40.4168&longitude=-3.7038&"
            "current=temperature_2m,relative_humidity_2m,wind_speed_10m,wind_direction_10m,wind_gusts_10m"
        )

    def fetch_stream_to_landing(self) -> str:
        logging.info("⚡ [REAL-TIME] Consultando datos meteorológicos en vivo...")
        
        try:
            response = requests.get(self.weather_url, timeout=30)
            if response.status_code != 200:
                logging.error(f"❌ Error al consultar Weather API: HTTP {response.status_code}")
                return None
            raw_data = response.text
        except Exception as e:
            logging.error(f"❌ Excepción en la ingesta meteorológica: {e}")
            return None

        now = datetime.now()
        year_str = now.strftime("%Y")
        month_str = now.strftime("%m")
        day_str = now.strftime("%d")
        hour_str = now.strftime("%H")

        dir_dest = os.path.join(self.base_landing_path, year_str, month_str, day_str, hour_str)
        os.makedirs(dir_dest, exist_ok=True)

        timestamp_str = now.strftime("%Y%m%d_%H%M%S")
        file_name = f"weather_{timestamp_str}.json"
        file_path = os.path.join(dir_dest, file_name)

        with open(file_path, "w", encoding="utf-8") as f:
            f.write(raw_data)

        logging.info(f"📥 [LANDING OK] Datos meteorológicos guardados en: {file_path}")
        return file_path