import os
import logging
import requests
from datetime import datetime

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

class DGTTrafficIngester:
    """Ingester NRT para incidencias reales de tráfico de la DGT (accidentes, retenciones, obras, cortes)."""

    def __init__(self, base_landing_path: str = "Files/landing/realtime/dgt_traffic"):
        self.base_landing_path = base_landing_path
        # Feed oficial de incidencias de la DGT en formato XML
        self.dgt_url = "https://nap.dgt.es/nap-incidencias/DATEXII_INCIDENCIAS.xml"
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) TFM_Mobility_App/1.0"
        }

    def fetch_stream_to_landing(self) -> str:
        logging.info("⚡ [REAL-TIME] Consultando incidencias de tráfico en tiempo real (DGT)...")
        
        try:
            response = requests.get(self.dgt_url, headers=self.headers, timeout=30)
            
            if response.status_code != 200:
                logging.error(f"❌ Error al consultar la DGT: HTTP {response.status_code}")
                return None
                
            raw_data = response.text
            
        except Exception as e:
            logging.error(f"❌ Excepción en la ingesta de incidencias DGT: {e}")
            return None

        now = datetime.now()
        year_str = now.strftime("%Y")
        month_str = now.strftime("%m")
        day_str = now.strftime("%d")
        hour_str = now.strftime("%H")

        dir_dest = os.path.join(self.base_landing_path, year_str, month_str, day_str, hour_str)
        os.makedirs(dir_dest, exist_ok=True)

        timestamp_str = now.strftime("%Y%m%d_%H%M%S")
        file_name = f"dgt_incidents_{timestamp_str}.xml"
        file_path = os.path.join(dir_dest, file_name)

        with open(file_path, "w", encoding="utf-8") as f:
            f.write(raw_data)

        logging.info(f"📥 [LANDING OK] Incidencias DGT guardadas en: {file_path}")
        return file_path