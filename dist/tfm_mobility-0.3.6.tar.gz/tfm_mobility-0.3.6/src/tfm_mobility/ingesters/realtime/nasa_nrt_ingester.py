import os
import logging
from datetime import datetime
from tfm_mobility.utils.api_client import APIClient

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

class NASANRTIngester:
    """Ingester NRT para incendios activos desde NASA FIRMS."""

    def __init__(self, base_landing_path: str = "Files/landing/realtime/nasa_nrt"):
        self.base_landing_path = base_landing_path
        self.firms_url = "https://firms.modaps.eosdis.nasa.gov/data/active_fire/suomi-npp-viirs-c2/csv/SUOMI_VIIRS_C2_Europe_24h.csv"
        self.client = APIClient()

    def fetch_stream_to_landing(self) -> str:
        logging.info("⚡ [REAL-TIME] Consultando feed Near-Real-Time de NASA FIRMS...")
        raw_data = self.client.get_text(self.firms_url)

        if not raw_data:
            logging.error("❌ Fallo en la recepción del feed de NASA FIRMS NRT.")
            return None

        now = datetime.now()
        year_str = now.strftime("%Y")
        month_str = now.strftime("%m")
        day_str = now.strftime("%d")
        hour_str = now.strftime("%H")

        dir_dest = os.path.join(self.base_landing_path, year_str, month_str, day_str, hour_str)
        os.makedirs(dir_dest, exist_ok=True)

        timestamp_str = now.strftime("%Y%m%d_%H%M%S")
        file_name = f"nasa_nrt_{timestamp_str}.csv"
        file_path = os.path.join(dir_dest, file_name)

        with open(file_path, "w", encoding="utf-8") as f:
            f.write(raw_data)

        logging.info(f"🚨 [HOT LANDING OK] Alerta NRT guardada en: {file_path}")
        return file_path