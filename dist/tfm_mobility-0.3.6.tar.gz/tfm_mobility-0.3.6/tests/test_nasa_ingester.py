import os
from unittest.mock import patch
from tfm_mobility.ingesters.realtime.nasa_nrt_ingester import NASANRTIngester

@patch("tfm_mobility.utils.api_client.APIClient.get_text")
def test_nasa_nrt_ingester_success(mock_get_text, tmp_path):
    fake_csv = "latitude,longitude,brightness\n40.4,-3.7,300.0"
    mock_get_text.return_value = fake_csv

    ingester = NASANRTIngester(base_landing_path=str(tmp_path))
    result_path = ingester.fetch_stream_to_landing()

    assert result_path is not None
    assert os.path.exists(result_path)

    with open(result_path, "r", encoding="utf-8") as f:
        content = f.read()

    assert "brightness" in content