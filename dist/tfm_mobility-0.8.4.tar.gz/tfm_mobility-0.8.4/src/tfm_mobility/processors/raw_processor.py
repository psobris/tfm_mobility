import logging
import os
import xml.etree.ElementTree as ET
from typing import Optional
from pyspark.sql import SparkSession

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

class RawProcessor:
    """Procesador robusto para convertir ficheros Landing (JSON/CSV/XML) a Parquet estructurado en RAW."""

    def __init__(self, spark: SparkSession):
        self.spark = spark

    def _sanitize_path(self, path: str) -> str:
        """Normaliza las rutas para el driver ABFS de Spark en Microsoft Fabric."""
        if not path:
            return ""
        clean = os.path.normpath(path).replace("\\", "/")
        for prefix in ["/lakehouse/default/", "lakehouse/default/"]:
            if clean.startswith(prefix):
                clean = clean[len(prefix):]
        if clean.startswith("/Files/"):
            clean = clean[1:]
        return clean

    def landing_to_raw_csv(self, landing_path: str, raw_path: Optional[str] = None, is_batch: bool = False) -> None:
        """Lee un archivo CSV de Landing y lo guarda como Parquet en RAW."""
        try:
            target_raw = raw_path or "Files/raw/realtime/csv_data"
            clean_landing = self._sanitize_path(landing_path)
            clean_raw = self._sanitize_path(target_raw)
            
            logging.info(f"📄 Leyendo CSV Landing (is_batch={is_batch}): {clean_landing}")
            df = self.spark.read.option("header", "true").option("inferSchema", "true").csv(clean_landing)
            
            df.write.format("parquet").mode("overwrite").save(clean_raw)
            logging.info(f"✅ Convertido a Parquet RAW en: {clean_raw}")
        except Exception as e:
            logging.error(f"❌ Error al convertir CSV a RAW ({landing_path}): {e}")

    def landing_to_raw_json(self, landing_path: str, raw_path: Optional[str] = None, is_batch: bool = False) -> None:
        """Lee un archivo JSON de Landing y lo guarda como Parquet en RAW."""
        try:
            target_raw = raw_path or "Files/raw/realtime/json_data"
            clean_landing = self._sanitize_path(landing_path)
            clean_raw = self._sanitize_path(target_raw)
            
            logging.info(f"📄 Leyendo JSON Landing (is_batch={is_batch}): {clean_landing}")
            df = self.spark.read.option("multiline", "true").json(clean_landing)
            
            df.write.format("parquet").mode("overwrite").save(clean_raw)
            logging.info(f"✅ Convertido a Parquet RAW en: {clean_raw}")
        except Exception as e:
            logging.error(f"❌ Error al convertir JSON a RAW ({landing_path}): {e}")

    def landing_to_raw_osm(self, landing_path: str, raw_path: Optional[str] = None) -> None:
        """Lee la red viaria de OSM en JSON y la promociona a Parquet RAW."""
        target_raw = raw_path or "Files/raw/batch/osm_roads"
        logging.info(f"🗺️ Procesando red viaria OSM desde {landing_path} a {target_raw}...")
        self.landing_to_raw_json(landing_path, target_raw, is_batch=True)

    def landing_to_raw_dgt_xml(self, landing_path: str, raw_path: Optional[str] = None) -> None:
        """Parsea XML de DGT Tráfico e incidencias y lo promociona a Parquet RAW."""
        try:
            target_raw = raw_path or "Files/raw/realtime/dgt_traffic"
            clean_landing = self._sanitize_path(landing_path)
            clean_raw = self._sanitize_path(target_raw)
            
            # Para operaciones de lectura directa en el sistema de archivos local (ET.parse)
            local_landing = f"/lakehouse/default/{clean_landing}" if not clean_landing.startswith("/lakehouse/default/") else clean_landing
            
            logging.info(f"📄 Procesando XML DGT Landing: {local_landing}")
            tree = ET.parse(local_landing)
            root = tree.getroot()
            
            records = []
            for elem in root.iter():
                if elem.attrib or elem.text:
                    row = {child.tag: child.text.strip() for child in elem if child.text}
                    if row:
                        records.append(row)
                        
            if records:
                df = self.spark.createDataFrame(records)
                df.write.format("parquet").mode("overwrite").save(clean_raw)
                logging.info(f"✅ XML DGT convertido a Parquet RAW en: {clean_raw}")
            else:
                logging.warning(f"⚠️ XML DGT sin registros parseables: {clean_landing}")
        except Exception as e:
            logging.error(f"❌ Error al convertir XML DGT a RAW ({landing_path}): {e}")

    def process_realtime_sources(self) -> None:
        """Procesa todas las fuentes NRT en Landing."""
        base_landing = "/lakehouse/default/Files/landing/realtime"
        base_raw = "Files/raw/realtime"

        # 1. Weather (JSON)
        weather_landing = os.path.join(base_landing, "weather")
        if os.path.exists(weather_landing):
            files = [os.path.join(weather_landing, f) for f in os.listdir(weather_landing) if f.endswith(".json")]
            if files:
                self.landing_to_raw_json(sorted(files)[-1], os.path.join(base_raw, "weather"), is_batch=False)

        # 2. NASA NRT (CSV)
        nasa_landing = os.path.join(base_landing, "nasa_nrt")
        if os.path.exists(nasa_landing):
            csv_files = []
            for root, _, files in os.walk(nasa_landing):
                for f in files:
                    if f.endswith(".csv"):
                        csv_files.append(os.path.join(root, f))
            if csv_files:
                self.landing_to_raw_csv(sorted(csv_files)[-1], os.path.join(base_raw, "nasa_nrt"), is_batch=False)

        # 3. DGT Traffic
        dgt_landing = os.path.join(base_landing, "dgt_traffic")
        if os.path.exists(dgt_landing):
            for root, _, files in os.walk(dgt_landing):
                for f in files:
                    full_p = os.path.join(root, f)
                    if f.endswith(".xml"):
                        self.landing_to_raw_dgt_xml(full_p, os.path.join(base_raw, "dgt_traffic"))
                    elif f.endswith(".json"):
                        self.landing_to_raw_json(full_p, os.path.join(base_raw, "dgt_traffic"), is_batch=False)

    def process_batch_sources(self) -> None:
        """Procesa todas las fuentes Batch en Landing (OSM, NASA Histórico)."""
        base_landing = "/lakehouse/default/Files/landing/batch"
        base_raw = "Files/raw/batch"

        # 1. OSM Roads (JSON)
        osm_landing = os.path.join(base_landing, "osm_roads")
        if os.path.exists(osm_landing):
            files = [os.path.join(osm_landing, f) for f in os.listdir(osm_landing) if f.endswith(".json")]
            if files:
                self.landing_to_raw_osm(sorted(files)[-1], os.path.join(base_raw, "osm_roads"))

        # 2. NASA Historical (CSV)
        nasa_hist_landing = os.path.join(base_landing, "nasa_historical")
        if os.path.exists(nasa_hist_landing):
            csv_files = []
            for root, _, files in os.walk(nasa_hist_landing):
                for f in files:
                    if f.endswith(".csv"):
                        csv_files.append(os.path.join(root, f))
            if csv_files:
                self.landing_to_raw_csv(sorted(csv_files)[-1], os.path.join(base_raw, "nasa_historical"), is_batch=True)