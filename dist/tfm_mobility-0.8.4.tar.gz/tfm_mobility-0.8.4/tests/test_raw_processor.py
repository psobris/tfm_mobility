from unittest.mock import MagicMock
from tfm_mobility.processors.raw_processor import RawProcessor

def test_raw_processor_sanitize_path():
    mock_spark = MagicMock()
    processor = RawProcessor(mock_spark)

    dirty_path = "/lakehouse/default/Files/landing/realtime/test.csv"
    clean_path = processor._sanitize_path(dirty_path)

    assert clean_path == "Files/landing/realtime/test.csv"

def test_raw_processor_optional_raw_path():
    mock_spark = MagicMock()
    processor = RawProcessor(mock_spark)
    
    # Comprobar que las funciones aceptan llamadas con 1 solo parámetro
    try:
        processor.landing_to_raw_osm("invalid_path.json")
        processor.landing_to_raw_dgt_xml("invalid_path.xml")
    except Exception as e:
        assert False, f"Lanzó excepción insospechada: {e}"