from unittest.mock import patch, MagicMock
from tfm_mobility.ingesters.realtime.weather_ingester import WeatherIngestor

@patch("requests.get")
def test_fetch_forecast_success(mock_get):
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = [{
        "latitude": 40.0,
        "longitude": -3.0,
        "elevation": 600,
        "hourly": {
            "time": ["2026-08-06T00:00"],
            "temperature_2m": [22.5],
            "precipitation_probability": [0],
            "precipitation": [0.0],
            "wind_speed_10m": [12.1]
        }
    }]
    mock_get.return_value = mock_response

    ingestor = WeatherIngestor(step_degrees=2.0)
    df = ingestor.fetch_forecast(forecast_days=7)

    assert df is not None
    assert len(df) >= 1
    assert "temperature_2m" in df.columns