import os
from unittest.mock import patch, MagicMock
from tfm_mobility.ingesters.realtime.dgt_traffic_ingester import DGTTrafficIngester

@patch("requests.post")
def test_dgt_traffic_ingester_success(mock_post, tmp_path):
    fake_json = '{"elements": [{"type": "node", "id": 123, "lat": 40.4, "lon": -3.7}]}'
    
    # Simular una respuesta 200 OK de requests
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.text = fake_json
    mock_post.return_value = mock_response

    ingester = DGTTrafficIngester(base_landing_path=str(tmp_path))
    result_path = ingester.fetch_stream_to_landing()

    assert result_path is not None
    assert os.path.exists(result_path)

    with open(result_path, "r", encoding="utf-8") as f:
        content = f.read()
    
    assert "40.4" in content