import logging
import os
import json
from datetime import datetime
import requests
from typing import Optional, Dict, Any

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

# Lista de endpoints espejo de Overpass API por si falla el principal
OVERPASS_ENDPOINTS = [
    "https://overpass-api.de/api/interpreter",
    "https://overpass.kumi.systems/api/interpreter",
    "https://maps.mail.ru/osm/tools/overpass/api/interpreter"
]

class OSMIngester:
    """Ingestor para la red viaria de España desde OpenStreetMap (Overpass API)."""

    def __init__(self, bbox: str = "35.8,-9.3,43.8,3.3"):
        self.bbox = bbox

    def fetch_roads(self) -> Optional[Dict[str, Any]]:
        """Descarga la red de carreteras principales de España desde Overpass."""
        # Query Overpass para autovías, autopistas y carreteras principales en el Bounding Box
        query = f"""
        [out:json][timeout:180];
        (
          way["highway"~"motorway|trunk|primary"]({self.bbox});
        );
        out body qt 1000;
        """
        
        headers = {
            "User-Agent": "TFMMobilityApp/1.0 (contact: paula.sobrados@example.com)",
            "Accept": "application/json"
        }

        for endpoint in OVERPASS_ENDPOINTS:
            try:
                logging.info(f"🗺️ [OSM] Solicitando carreteras a Overpass endpoint: {endpoint}...")
                response = requests.post(endpoint, data={"data": query}, headers=headers, timeout=120)
                response.raise_for_status()
                
                data = response.json()
                elements = data.get("elements", [])
                logging.info(f"✅ [OSM OK] Obtenidos {len(elements)} tramos de carretera.")
                return data

            except Exception as e:
                logging.warning(f"⚠️ [OSM WARNING] Falló endpoint {endpoint}: {e}")
                continue

        logging.error("❌ [OSM ERROR] Fallaron todos los endpoints de Overpass API.")
        return None

    def fetch_stream_to_landing(self, landing_dir: str = "/lakehouse/default/Files/landing/batch/osm_roads") -> Optional[str]:
        """Guarda la respuesta JSON de OSM en la zona Landing Batch."""
        data = self.fetch_roads()
        if not data:
            return None

        os.makedirs(landing_dir, exist_ok=True)
        timestamp_str = datetime.now().strftime("%Y%m%d_%H%M%S")
        file_path = os.path.join(landing_dir, f"osm_roads_{timestamp_str}.json")

        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False)

        logging.info(f"💾 [OSM LANDING] Red viaria guardada en: {file_path}")
        return file_path