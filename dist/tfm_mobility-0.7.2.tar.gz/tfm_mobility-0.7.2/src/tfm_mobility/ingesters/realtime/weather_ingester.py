import os
import logging
import requests
import time
from datetime import datetime

logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

class WeatherIngester:
    """Ingester NRT para datos meteorológicos en tiempo real."""

    def __init__(self, base_landing_path: str = "Files/landing/realtime/weather"):
        self.base_landing_path = base_landing_path.replace("/lakehouse/default/", "")
        self.url = "https://api.open-meteo.com/v1/forecast?latitude=40.4168&longitude=-3.7038&current=temperature_2m,relative_humidity_2m,wind_speed_10m,wind_direction_10m,wind_gusts_10m"

    def fetch_stream_to_landing(self) -> str:
        logging.info("⚡ [REAL-TIME] Consultando datos meteorológicos en vivo...")
        response = None
        for attempt in range(1, 4):
            try:
                response = requests.get(self.url, timeout=15)
                if response.status_code == 200:
                    break
            except Exception as e:
                logging.warning(f"⚠️ Reintento {attempt}/3 en Weather debido a: {e}")
                time.sleep(1)

        if not response or response.status_code != 200:
            logging.error("❌ No se pudo obtener respuesta de la API meteorológica.")
            return None

        now = datetime.now()
        dir_dest = os.path.join(
            self.base_landing_path,
            now.strftime("%Y"),
            now.strftime("%m"),
            now.strftime("%d"),
            now.strftime("%H")
        )
        local_dir = os.path.join("/lakehouse/default", dir_dest) if not dir_dest.startswith("/lakehouse/default") else dir_dest
        os.makedirs(local_dir, exist_ok=True)

        file_name = f"weather_{now.strftime('%Y%m%d_%H%M%S')}.json"
        local_file_path = os.path.join(local_dir, file_name)

        with open(local_file_path, "w", encoding="utf-8") as f:
            f.write(response.text)

        spark_file_path = os.path.join(dir_dest, file_name).replace("\\", "/")
        logging.info(f"📥 [LANDING OK] Datos meteorológicos guardados en: {spark_file_path}")
        return spark_file_path